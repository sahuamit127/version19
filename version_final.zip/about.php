<html lang="en">
    <head>
		 <title>Version'19</title>
		 <link rel="icon" href="logo/logo.png" type="image/gif" sizes="16x16">
		     <meta http-equiv="X-UA-Compatible" content="IE=edge">
             <meta name="viewport" content="width=device-width, initial-scale=1">
		     <meta charset="utf-8">
		
		    <!--style Section-->
			<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

              <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700%7CPoppins:400,500" rel="stylesheet">
 <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css'>
             <link rel="stylesheet" href="css/card.css">
	          <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700' rel='stylesheet' type='text/css'>
			  <!--info section-->
			      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
	              <link rel="stylesheet" href="css/info.css">
			       <link href="http://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
	          <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700' rel='stylesheet' type='text/css'>
 <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Iceland" />
			  <!--end of info section-->
 <!--menu script and style-->
	<link rel="stylesheet" href="css/menu/spinkit.css">	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
<script type="text/javascript" src="js/menu/app.js"></script>
  <script type="text/javascript" src="js/menu/spinkit.js"></script>
  <!--end menu-->
			   
	        
	          <link href="css/bubble_style.css" rel="stylesheet">
	          
		     <style type="text/css">

			body {
				background-image:url('img/background.png');
				margin: 0px;
				
				font-family:Monospace;
				font-size:13px;
				text-align:center;
				font-weight: bold;
				text-align:center;
			}

			a {
				color:#0078ff;
			}
			   .heading{
			font-size:54px;
			font-weight:700;
			text-align:center;
			color:#fff;
			margin-top:3%;
			margin-bottom:5%;
			font-family:iceland;
			}
            
			    canvas {
	position: absolute;
	top: 0;
	left: 0;
	z-index:100;
}
section {
    padding: 13px 0;
}

section .section-title {
    text-align: center;
    color: #fff;
	font-family:iceland;
	font-size:48px;
    margin-bottom: 50px;
    text-transform: uppercase;
}
#team .card {
    border: none;
    background:#f1f4f6a3;
	box-shadow:2px 2px 6px 6px #8b88d7;
}






.frontside {
    position: relative;
    -webkit-transform: rotateY(0deg);
    -ms-transform: rotateY(0deg);
    z-index: 2;
    margin-bottom: 30px;
}

.about_img{
width:36%;

}
@media only screen and (max-width:500px) {
.about_img{
width:80%;

}
}
.frontside {
    -webkit-backface-visibility: hidden;
    -moz-backface-visibility: hidden;
    -ms-backface-visibility: hidden;
    backface-visibility: hidden;
    -webkit-transition: 1s;
    -webkit-transform-style: preserve-3d;
    -moz-transition: 1s;
    -moz-transform-style: preserve-3d;
    -o-transition: 1s;
    -o-transform-style: preserve-3d;
    -ms-transition: 1s;
    -ms-transform-style: preserve-3d;
    transition: 1s;
    transform-style: preserve-3d;
}

.frontside .card{
    min-height: 365px;
}



.frontside .card .card-title
 {
    color: #007b5e !important;
}

.frontside .card .card-body img {
    width: 150px;
    height: 150px;
    border-radius: 50%;
}
.card-body
{
padding-left:0px;
padding-right:0px;

}



h4{
font-size:18px;
margin-top:17px;

}
h6{
margin-top:17px;
font-size:15px;font-weight:600;

}
	
			
		</style>
	</head>
	
	
             <!--end of stylesheet section-->
		
	        <!--start body section-->
	
	<body>
		     <!-- content section-->
              <!--///////////////////////////////-->
			  <!--edge network background-->
           

              <div id="particles-js" style="position:fixed;"></div> 
 
            <script src="http://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
              <!-- Background small bubble -->
	        
                <div style="position:absolute;z-index:1000;height:100%;width:100%;text-align:left;">
          <div class="info_container">
   <div class="heading">Information</div>
  <div class="slides">
    <div class="slide active">
      <a href="#">About Version</a>
      <div class="content">
	         <img src=".\img\Version_white.png" class="about_img"><br>
        Version, an All India MCA Meet is an exhilarating event conducted by Department Of Computer Applications at National Institute of Technology, Tiruchirappalli.
		In the year 1991, there emerged an idea to provide a common arena to all the coders and geeks of India to exhibit their extraordinary abilities. 
		And that idea caused the birth of this marvellous event named VERSION. Every year with new enthusiasm and spirit Version acts a dais for those who are ready with there minds as swords to win the battlefield of programming and coding.
		Each year Version’s theme enables participants to know about and to focus on current technologies in computers science.
		The journey towards new dimensions with a new and novel theme every year- peaking towards success continues.      </div>
    </div>
    
    <div class="slide">
      <a href="#" >About Theme</a>
      <div class="content">
	  	 <img src=".\img\t_logo.png" class="about_img"><br>
        The theme of VERSION'19 is KNOTRYX,which mainly focuses on Edge Computing.         
		Edge computing is a networking philosophy focused on bringing computing as close to the 
		source of data as possible in order to reduce latency and bandwidth use. 
		It is a mesh network of microdata centers that process or store critical data locally 
		and push all received data to a central data center or cloud storage repository.
		In simpler terms, edge computing means running fewer processes in the cloud and moving 
		those processes to local places, such as on a user&#39;s computer, an IoT device, or an edge server. 
		Bringing computation to the network&#39;s edge minimizes the amount of long-distance communication 
		that has to happen between a client and server.
  </div>
    </div>
    
    <div class="slide">
      <a href="#">Support</a>
      <div class="content">
	  <section id="team" class="pb-5">
    <div class="container">
        
        <div class="row">
            <!-- Team member -->
            <div class="col-xs-4 col-sm-6 col-md-4">
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="images/hod.jpeg" alt="card image"></p>
                                    <h4 class="card-title">Dr. S. R. Balasundaram</h4>
                                    <h6>Head of the Department</h6>
									<h4>Department of Computer Applications</h4>
									
                                </div>
                            </div>
                        </div>      
            </div>
            <!-- ./Team member -->
            <!-- Team member -->
            <div class="col-xs-4 col-sm-6 col-md-4">                    
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="images/sangeetha.jpg" alt="card image"></p>
                                    <h4 class="card-title">Dr.(Mrs.) S. Sangeetha</h4>
                                    <h6>Staff Advisor</h6>
                                    <h4>Version</h4>
									
                                </div>
                            </div>
                        </div>
            </div>
            <!-- ./Team member -->
            <!-- Team member -->
            <div class="col-xs-4 col-sm-6 col-md-4">
                       <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="images/ccc/0.jpeg" alt="card image"></p>
                                    <h4 class="card-title">Sumesh Mishra</h4>
                                    <h6>Chairman</h6>
									<h4 >Version'19</h4>
									
                                </div>
                            </div>
                        </div>
            </div>
            <!-- ./Team member -->
            <!-- Team member -->
           
            <!-- ./Team member -->
          
            <!-- ./Team member -->

        </div>
    </div>
</section>
      </div>
    </div>
  </div>
</div>
                        
                        


                        


						
                   <!-- menu Icon-->
   <div class="site-nav-animation-wrapper menu-animation-wrapper">
      <div class="site-nav-animated-background menu-animated-background"></div>
    </div>
    <a href="#" class="menu menu-white menu-spinkit" style="position:fixed;">
      <span class="menu-icon-line-1 menu-icon-line"></span>
      <span class="menu-icon-line-2 menu-icon-line"></span>
      <span class="menu-icon-line-3 menu-icon-line"></span>
    </a>

   <div class="site-nav-overlay js-nav">
      <div class="nav-content">
        <div class="js-nav-header nav-header">
          <span class="nav-header-text">Version'19</span>
          <div class="nav-header-line js-nav-header-line"></div>
        </div>

        <ul class="nav-categories">
          <li class="nav-category js-nav-animate"><a href="index.php" class="nav-link">Home</a></li>
          <li class="nav-category js-nav-animate"><a href="event.php" class="nav-link">Event</a></li>
          <li class="nav-category js-nav-animate"><a href="team.php" class="nav-link">Teams</a></li>
          <li class="nav-category js-nav-animate"><a href="contact.php" class="nav-link">Contact</a></li>
		  <li class="nav-category js-nav-animate"><a href="#" class="nav-link">About</a></li>
		  <li class="nav-category js-nav-animate"><a href="gallery.php" class="nav-link">Gallery</a></li>
		  <li class="nav-category js-nav-animate"><a href="" class="nav-link">Registration</a></li>
        </ul>

        <div class="nav-sublinks js-nav-animate">
          <div class="js-nav-animate">
          <a class="nav-link nav-sublink" target="_blank" href="https://www.facebook.com/versionmeet/"><i class="fab fa-facebook-f"></i></a>
          <a class="nav-link nav-sublink" target="_blank" href="https://www.youtube.com/channel/UCtD7JZ4zH72M8lSzo1y89gQ"><i class="fab fa-youtube"></i></a>
          <a class="nav-link nav-sublink" target="_blank" href="https://www.instagram.com/version_nit_trichy/"><i class="fab fa-instagram"></i></a>
          </div>
        </div>
      </div>

    </div>

              <!-- end of section-->
			  
			  <!--script section-->
	    <script src="https://cdn.jsdelivr.net/gh/cferdinandi/smooth-scroll@15.0.0/dist/smooth-scroll.polyfills.min.js"></script>
            <script  src="js/info.js"></script>

	    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
        
	     <script  src="bubble_background.js"></script>
		 
		  
 
    </body>
</html>