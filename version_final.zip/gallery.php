<html lang="en">
    <head>
		  <title>Version'19</title>
		 <link rel="icon" href="logo/logo.png" type="image/gif" sizes="16x16">
		     <meta http-equiv="X-UA-Compatible" content="IE=edge">
             <meta name="viewport" content="width=device-width, initial-scale=1">
		     <meta charset="utf-8">
		
		    <!--style Section-->
			<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
                 <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Iceland" />
              <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700%7CPoppins:400,500" rel="stylesheet">
              <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css'>
               <link rel="stylesheet" type="text/css" href="gallery/engine1/style.css" />
	           <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700' rel='stylesheet' type='text/css'>
 <!--menu script and style-->
 
      <link rel="stylesheet" href="css/center_lines.css">	
	<link rel="stylesheet" href="css/menu/spinkit.css">	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
<script type="text/javascript" src="js/menu/app.js"></script>
  <script type="text/javascript" src="js/menu/spinkit.js"></script>
  <!--end menu-->
			   <link rel="stylesheet" href="css/timer.css">
	        
	          <link href="css/bubble_style.css" rel="stylesheet">
	          
		     <style type="text/css">

			body {
				background-image:url('img/background.png');
				margin: 0px;
				
				font-family:Monospace;
				font-size:13px;
				text-align:center;
				font-weight: bold;
				text-align:center;
			}

			a {
				color:#0078ff;
			}
			.heading{
			font-size:54px;
			font-weight:700;
			color:#fff;
			margin-top:3%;
			margin-bottom:2%;
			margin-left:6%;
			font-family:iceland;
			text-align:center;
			}
            
			    canvas {
	position: absolute;
	top: 0;
	left: 0;
	z-index:100;
}
.mcalogo{
height:43px;width:175px;padding-left:5%;margin-top:0.5%;
float:left;

}
.versionlogo{
width:100%;padding-top:4%;padding-bottom:23%;padding-left:6%;

}
.versionlogo img{
height:100px;width:400px;

}

.nittlogo
{
height:110px;width:110px;float:right;padding-right:0.5%;padding-top:0.5%;

}
@media only screen and (max-width:500px) {
.nittlogo
{
height:80px;width:80px;float:right;padding-right:0.5%;padding-top:0.5%;

}
.mcalogo{
display:none;

}
.versionlogo {
width:100%;padding-top:23%;padding-bottom:10%;padding-left:2%;

}

.versionlogo img{
height:50px;width:200px;

}
}
			
		</style>
	</head>
	
	
             <!--end of stylesheet section-->
		
	        <!--start body section-->
	
	<body>
		     <!-- content section-->
              <!--///////////////////////////////-->
			 
           

              <div id="particles-js"></div> 
 
            <script src="http://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
              <!-- Background small bubble -->
	        
                <div style="position:absolute;z-index:1000;height:100%;width:100%;text-align:left;">
             <div style="width:100%;" >
						            <img src="img/mcalogo.png"  class="mcalogo">   
                                   <img src="img/logo.png" class="nittlogo">
	                   		
							</div>	<br>	   
                       
		  <!--Gallery Section-->
 <div class="heading">Gallery</div>
	<div id="wowslider-container1">
	<div class="ws_images"><ul>
		<li><img src="gallery/data1/images/4.jpg" alt="4" title="4" id="wows1_0"/></li>
		<li><img src="gallery/data1/images/5.jpg" alt="5" title="5" id="wows1_1"/></li>
		<li><img src="gallery/data1/images/6.jpg" alt="6" title="6" id="wows1_2"/></li>
		<li><img src="gallery/data1/images/7.jpg" alt="7" title="7" id="wows1_3"/></li>
		<li><img src="gallery/data1/images/8.jpg" alt="8" title="8" id="wows1_4"/></li>
		<li><img src="gallery/data1/images/1.jpg" alt="1" title="1" id="wows1_5"/></li>
		<li><a href="http://wowslider.net"><img src="gallery/data1/images/2.jpg" alt="javascript slider" title="2" id="wows1_6"/></a></li>
		<li><img src="gallery/data1/images/3.jpg" alt="3" title="3" id="wows1_7"/></li>
	</ul></div>
	<div class="ws_bullets"><div>
		<a href="#" title="4"><span><img src="gallery/data1/tooltips/4.jpg" alt="4"/>1</span></a>
		<a href="#" title="5"><span><img src="gallery/data1/tooltips/5.jpg" alt="5"/>2</span></a>
		<a href="#" title="6"><span><img src="gallery/data1/tooltips/6.jpg" alt="6"/>3</span></a>
		<a href="#" title="7"><span><img src="gallery/data1/tooltips/7.jpg" alt="7"/>4</span></a>
		<a href="#" title="8"><span><img src="gallery/data1/tooltips/8.jpg" alt="8"/>5</span></a>
		<a href="#" title="1"><span><img src="gallery/data1/tooltips/1.jpg" alt="1"/>6</span></a>
		<a href="#" title="2"><span><img src="gallery/data1/tooltips/2.jpg" alt="2"/>7</span></a>
		<a href="#" title="3"><span><img src="gallery/data1/tooltips/3.jpg" alt="3"/>8</span></a>
	</div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">javascript photo gallery</a> by WOWSlider.com v8.8</div>
	<div class="ws_shadow"></div>
	</div>	








                        
                        
                       


			<!--end-->			
                   <!-- menu Icon-->
   <div class="site-nav-animation-wrapper menu-animation-wrapper">
      <div class="site-nav-animated-background menu-animated-background"></div>
    </div>
    <a href="#" class="menu menu-white menu-spinkit" style="position:fixed;">
      <span class="menu-icon-line-1 menu-icon-line"></span>
      <span class="menu-icon-line-2 menu-icon-line"></span>
      <span class="menu-icon-line-3 menu-icon-line"></span>
    </a>

    <div class="site-nav-overlay js-nav">
      <div class="nav-content">
        <div class="js-nav-header nav-header">
          <span class="nav-header-text">Version'19</span>
          <div class="nav-header-line js-nav-header-line"></div>
        </div>

        <ul class="nav-categories">
          <li class="nav-category js-nav-animate"><a href="#" class="nav-link">Home</a></li>
          <li class="nav-category js-nav-animate"><a href="event.php" class="nav-link">Event</a></li>
          <li class="nav-category js-nav-animate"><a href="team.php" class="nav-link">Teams</a></li>
          <li class="nav-category js-nav-animate"><a href="contact.php" class="nav-link">Contact</a></li>
		  <li class="nav-category js-nav-animate"><a href="about.php" class="nav-link">About</a></li>
		  <li class="nav-category js-nav-animate"><a href="#" class="nav-link">Gallery</a></li>
		  <li class="nav-category js-nav-animate"><a href="register.php" class="nav-link">Registration</a></li>
        </ul>

        <div class="nav-sublinks js-nav-animate">
          <div class="js-nav-animate">
          <a class="nav-link nav-sublink" target="_blank" href="https://www.facebook.com/versionmeet/"><i class="fab fa-facebook-f"></i></a>
          <a class="nav-link nav-sublink" target="_blank" href="https://www.youtube.com/channel/UCtD7JZ4zH72M8lSzo1y89gQ"><i class="fab fa-youtube"></i></a>
          <a class="nav-link nav-sublink" target="_blank" href="https://www.instagram.com/version_nit_trichy/"><i class="fab fa-instagram"></i></a>
          </div>
        </div>
      </div>
    
    </div>
	
	<div style="position:fixed;bottom:1%;color:#fff;width:100%;text-align:center;font-size:15px;">
	Made With ❤️ By EEC.
	</div>
	<!--footer Section-->

</div>
              <!-- end of section-->
			  
			  <!--script section-->
	    <script src="https://cdn.jsdelivr.net/gh/cferdinandi/smooth-scroll@15.0.0/dist/smooth-scroll.polyfills.min.js"></script>
        <script type="text/javascript" src="gallery/engine1/jquery.js"></script>
	    
	    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
       <script type="text/javascript" src="gallery/engine1/wowslider.js"></script>
	<script type="text/javascript" src="gallery/engine1/script.js"></script>
	     <script  src="bubble_background.js"></script>
		 <script  src="js/center_lines.js"></script>
		  <script  src="js/timer.js"></script>
 
    </body>
</html>