<html lang="en">
    <head>
		  <title>Version'19</title>
		 <link rel="icon" href="logo/logo.png" type="image/gif" sizes="16x16">
		  
		    <!--style Section-->
	
	  <meta http-equiv="X-UA-Compatible" content="IE=edge">
             <meta name="viewport" content="width=device-width, initial-scale=1">
		     <meta charset="utf-8">
  <!--end menu-->
			                 <!--team styles-->
			               <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
                           <link rel="stylesheet" type="text/css" href="css/team/demo.css" />
		                   <link rel="stylesheet" type="text/css" href="css/team/common.css" />
                          <link rel="stylesheet" type="text/css" href="css/team/style5.css" />
						  <link href="css/team/tabbar.css" rel="stylesheet">
						  <!----------------------->
						  
                            <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Iceland" />
              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	          <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
               
			   
			  
			  		<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,700' rel='stylesheet' type='text/css' />
	        		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
                       <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	          <link href="style.css" rel="stylesheet">
	         
		     <style type="text/css">

			body {
				background-image:url('img/background.png');
				margin: 0px;
				
				font-family:Monospace;
				font-size:13px;
				text-align:center;
				font-weight: bold;
				text-align:center;
			}

			a {
				color:#0078ff;
			}
           .heading{
			font-size:50px;
			font-weight:700;
			color:#fff;
			margin-top:1%;
			font-family:iceland;
			}

		</style>
		

		
		
	</head>

	
             <!--end of stylesheet section-->
		
	        <!--start body section-->
	
	<body>
		     <!-- content section-->

             
              <!-- Background small bubble -->
	    <div id="particles-js" style="position:fixed;"></div> 
 
            <script src="http://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
				                <div style="position:absolute;z-index:1001;top:3%;left:2%;">
								<a href="index.php">
								 <i class="fas fa-home" style="font-size:48px;color:#fff;"></i></a>
                                 </div>
                <div style="position:absolute;z-index:1000;height:100%;width:100%;text-align:center;">
                 
				 
				 		<!--menu script and style-->
	                          
                                
							
                            	



   
  
				 
				 
			
				<!--team members--> 
				 <div class="container" style="width:100%;" >
    <div class="row" >
        <div class="col-md-12" >
            <div class="tab" role="tabpanel" >
                <!-- Nav tabs -->
                <ul class="nav nav-tabs" role="tablist" >
                    <li role="presentation" class="active"><a href="#ccc" role="tab" data-toggle="tab">ccc</a></li>
                    <li role="presentation"><a href="#eec"  role="tab"  data-toggle="tab">eec</a></li>
                    <li role="presentation"><a href="#ppc"  role="tab" data-toggle="tab">PPC</a></li>
					<li role="presentation"><a href="#prc"  role="tab" data-toggle="tab">PRC</a></li>
                    <li role="presentation"><a href="#rc"  role="tab" data-toggle="tab">RC</a></li>
					<li role="presentation"><a href="#hc"  role="tab" data-toggle="tab">HC</a></li>
                
                </ul>
                <!-- Tab panes -->
				
				
				
                <div class="tab-content tabs">
				
				<!-- CCC-->
				
				 <div role="tabpanel" class="tab-pane fade in active" id="ccc">
		    <div class="container_team">
			
		<hr/>
			<div class="heading">central co-ordination committee</div>
			  
			    <section class="main">
			
				<ul class="ch-grid">
				    <li style="height:180px;width:180px;margin-right:60px;margin-bottom:40px;">
						<div class="ch-item ch-img-1" style="height:180px;width:180px;">				
							<div class="ch-info-wrap" style="height:180px;width:180px;">
								<div class="ch-info" style="height:180px;width:180px;">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ccc/0.jpeg');"></div>
									<div class="ch-info-back">
										<h3 style="font-size: 24px;"><u>Chairman</u><br>SUMESH MISHRA</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ccc/1.jpg');"></div>
									<div class="ch-info-back">
										<h3><u>secretary</u><br>HARSH BHADORIA</h3>
										 
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ccc/2.jpeg');"></div>
									<div class="ch-info-back">
										<h3><u>treasurer</u><br>JAYESH MENGHANI</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ccc/3.jpeg');"></div>
									<div class="ch-info-back">
										<h3>ANKUR JAIN</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					</ul>
					<ul class="ch-grid">
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ccc/4.jpg');"></div>
									<div class="ch-info-back">
										<h3>JAY SINGH GAUD</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ccc/5.jpg');"></div>
									<div class="ch-info-back">
										<h3>RICHA AGARWAL</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ccc/6.jpeg');"></div>
									<div class="ch-info-back">
										<h3>VIPIN KUMAR NIRANJAN</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ccc/7.jpeg');"></div>
									<div class="ch-info-back">
										<h3>HIMANSHU SHINDE</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ccc/8.jpeg');"></div>
									<div class="ch-info-back">
										<h3>PUNEET PRJAPAT</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					</ul>
					
				
			</section>
			
            </div>
                
         </div>
		 
		 <!--eec-->
		 
		  <div role="tabpanel" class="tab-pane fade in" id="eec">
		    <div class="container_team">
			
		<hr/>
			<div class="heading">Event Execution committee</div>
			  
			    <section class="main">
			
				<ul class="ch-grid">
				    <li style="height:180px;width:180px;margin-right:60px;margin-bottom:40px;">
						<div class="ch-item ch-img-1" style="height:180px;width:180px;">				
							<div class="ch-info-wrap" style="height:180px;width:180px;">
								<div class="ch-info" style="height:180px;width:180px;">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/0.jpeg');"></div>
									<div class="ch-info-back">
										<h3 style="font-size: 24px;"><u>Chairman</u><br>Abhishek Rustagi</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/1.jpeg');"></div>
									<div class="ch-info-back">
										<h3>Ajay Lachheta</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/2.jpg');"></div>
									<div class="ch-info-back">
										<h3>Amit Sahu</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/3.jpeg');"></div>
									<div class="ch-info-back">
										<h3>ANKUR RANA</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/4.jpeg');"></div>
									<div class="ch-info-back">
										<h3>HARDIK JAIN</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/5.jpeg');"></div>
									<div class="ch-info-back">
										<h3>KARTIK GUPTA</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/6.jpeg');"></div>
									<div class="ch-info-back">
										<h3>KUNAL KUMAR BHAVSAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/7.jpeg');"></div>
									<div class="ch-info-back">
										<h3>KUNDAN</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/8.jpeg');"></div>
									<div class="ch-info-back">
										<h3>MAYUR GEHLOD</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/9.jpeg');"></div>
									<div class="ch-info-back">
										<h3>RAJ RISHI</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/10.jpeg');"></div>
									<div class="ch-info-back">
										<h3>RAVINA VERMA</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/11.jpeg');"></div>
									<div class="ch-info-back">
										<h3>ROHIT BAIRAGI</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/12.jpeg');"></div>
									<div class="ch-info-back">
										<h3>RUCHITA NAGAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/13.jpeg');"></div>
									<div class="ch-info-back">
										<h3>SAHIL GOEL</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/14.jpeg');"></div>
									<div class="ch-info-back">
										<h3>SHIVAM TIWARI</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/15.png');"></div>
									<div class="ch-info-back">
										<h3>SWEEKRITI SINGH</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/16.jpeg');"></div>
									<div class="ch-info-back">
										<h3>VAIBHAV VIKAS</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/eec/17.jpeg');"></div>
									<div class="ch-info-back">
										<h3>YASH KUMAR SINGHAL</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
				</ul>
				
			</section>
			
            </div>
                
         </div>
		 <!--ppc-->
		 
		  <div role="tabpanel" class="tab-pane fade in " id="ppc">
		    <div class="container_team">
			
		<hr/>
			<div class="heading">Printing and Publishing committee</div>
			  
			    <section class="main">
			
				<ul class="ch-grid">
				<li style="height:180px;width:180px;margin-right:60px;margin-bottom:40px;">
						<div class="ch-item ch-img-1" style="height:180px;width:180px;">				
							<div class="ch-info-wrap" style="height:180px;width:180px;">
								<div class="ch-info" style="height:180px;width:180px;">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/0.jpeg');"></div>
									<div class="ch-info-back">
										<h3 style="font-size: 24px;"><u>Chairman</u><br>MAHADEV RAJAK</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/1.jpeg');"></div>
									<div class="ch-info-back">
										<h3>AJAY SINGH</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/2.jpeg');"></div>
									<div class="ch-info-back">
										<h3>ANKIT GOSWAMI</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/3.jpeg');"></div>
									<div class="ch-info-back">
										<h3>HARSH PUROHIT</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/4.jpeg');"></div>
									<div class="ch-info-back">
										<h3>KAMAL PATIDAR</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/5.jpg');"></div>
									<div class="ch-info-back">
										<h3>KUNDAN THAKRE</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					</ul>
					<ul class="ch-grid">
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/6.jpeg');"></div>
									<div class="ch-info-back">
										<h3>PALASH SHUKLA</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/7.jpeg');"></div>
									<div class="ch-info-back">
										<h3>PATRICK TIRCKY</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/8.jpeg');"></div>
									<div class="ch-info-back">
										<h3>PRAFUL WAGHE</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/9.jpeg');"></div>
									<div class="ch-info-back">
										<h3>PRATEEK GURJAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/10.jpg');"></div>
									<div class="ch-info-back">
										<h3>RITU PARMAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					</ul>
					<ul class="ch-grid">
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/11.jpg');"></div>
									<div class="ch-info-back">
										<h3>SHIVANI MUCHHALA</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/12.jpeg');"></div>
									<div class="ch-info-back">
										<h3>SURYA PRAKASH PARMAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/13.jpeg');"></div>
									<div class="ch-info-back">
										<h3>SWAPNIL GUPTA</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/14.jpeg');"></div>
									<div class="ch-info-back">
										<h3>SWATI TAWAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/ppc/15.jpeg');"></div>
									<div class="ch-info-back">
										<h3>YUGANSH ARORA</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					
				</ul>
				
			</section>
			
            </div>
                
         </div>
		 <!--prc-->
		 
		  <div role="tabpanel" class="tab-pane fade in " id="prc">
		    <div class="container_team">
			
		<hr/>
			<div class="heading">Public Relation committee</div>
			  
			    <section class="main">
			
				<ul class="ch-grid">
				   <li style="height:180px;width:180px;margin-right:60px;margin-bottom:40px;">
						<div class="ch-item ch-img-1" style="height:180px;width:180px;">				
							<div class="ch-info-wrap" style="height:180px;width:180px;">
								<div class="ch-info" style="height:180px;width:180px;">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/0.jpeg');"></div>
									<div class="ch-info-back">
										<h3 style="font-size: 24px;"><u>Chairman</u><br>NAYAN BORANA</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/1.jpg');"></div>
									<div class="ch-info-back">
										<h3>ATUL GAURAV</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/2.jpeg');"></div>
									<div class="ch-info-back">
										<h3>DURGESH DHAKAD</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/3.jpeg');"></div>
									<div class="ch-info-back">
										<h3>KHUSBINDER </h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/4.jpeg');"></div>
									<div class="ch-info-back">
										<h3>LALCHAN PATEL</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/5.jpeg');"></div>
									<div class="ch-info-back">
										<h3>MAHESH KUMAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					</ul>
					<ul class="ch-grid">
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/6.jpeg');"></div>
									<div class="ch-info-back">
										<h3>MOHIT DIXIT</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/7.jpeg');"></div>
									<div class="ch-info-back">
										<h3>SAKSHI RAI</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/8.jpeg');"></div>
									<div class="ch-info-back">
										<h3>SAPNA DHAKSIYA</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/9.png');"></div>
									<div class="ch-info-back">
										<h3>SEFIYA KHAN</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/10.jpeg');"></div>
									<div class="ch-info-back">
										<h3>SONU SITOLE</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/11.jpeg');"></div>
									<div class="ch-info-back">
										<h3>SUKHLAL AHIRWAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					</ul>
					<ul class="ch-grid">
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/12.jpeg');"></div>
									<div class="ch-info-back">
										<h3>UDAY KUMAR BITTU</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/13.jpeg');"></div>
									<div class="ch-info-back">
										<h3>VAISHALI GOYAL</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/14.jpeg');"></div>
									<div class="ch-info-back">
										<h3>UMA MAHESH</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/15.jpeg');"></div>
									<div class="ch-info-back">
										<h3>YOGENDRA SINGH RAJPUT</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/prc/16.jpeg');"></div>
									<div class="ch-info-back">
										<h3>MOODAVATH VENKATESH</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					
				</ul>
				
			</section>
			
            </div>
                
         </div>
		 <!--rc-->
		 
		  <div role="tabpanel" class="tab-pane fade in " id="rc">
		    <div class="container_team">
			
		<hr/>
			<div class="heading">Reception committee</div>
			  
			    <section class="main">
			
				<ul class="ch-grid">
				   <li style="height:180px;width:180px;margin-right:60px;margin-bottom:40px;">
						<div class="ch-item ch-img-1" style="height:180px;width:180px;">				
							<div class="ch-info-wrap" style="height:180px;width:180px;">
								<div class="ch-info" style="height:180px;width:180px;">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/0.jpeg');"></div>
									<div class="ch-info-back">
										<h3 style="font-size: 24px;"><u>Chairman</u><br>ADITYA SAXENA</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/1.jpeg');"></div>
									<div class="ch-info-back">
										<h3>ABHISHEK JAISWAL</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/2.jpeg');"></div>
									<div class="ch-info-back">
										<h3>AKSHAY RATHOR</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/3.jpeg');"></div>
									<div class="ch-info-back">
										<h3>ANDAZ KUMAR</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/4.jpeg');"></div>
									<div class="ch-info-back">
										<h3>CHANDRA SHEKHAR</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/5.jpeg');"></div>
									<div class="ch-info-back">
										<h3>DASHRATH KUMAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					</ul>
					<ul class="ch-grid">
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/6.jpg');"></div>
									<div class="ch-info-back">
										<h3>DEVAM SINGH</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/7.jpeg');"></div>
									<div class="ch-info-back">
										<h3>KRISHNA KUMAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/8.jpg');"></div>
									<div class="ch-info-back">
										<h3>MAMTA PATIDAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/9.jpeg');"></div>
									<div class="ch-info-back">
										<h3>MAYANK JAIN</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/10.jpg');"></div>
									<div class="ch-info-back">
										<h3>NISHA JAPALE</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/11.jpeg');"></div>
									<div class="ch-info-back">
										<h3>RAJSHI SINGHAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					</ul>
					<ul class="ch-grid">
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/12.jpg');"></div>
									<div class="ch-info-back">
										<h3>SATYA PRAKASH</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/13.jpeg');"></div>
									<div class="ch-info-back">
										<h3>SAURABH SHARMA</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/14.jpeg');"></div>
									<div class="ch-info-back">
										<h3>SURAJ KUMAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/15.jpg');"></div>
									<div class="ch-info-back">
										<h3>VIPIN THAKUR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/rc/16.jpeg');"></div>
									<div class="ch-info-back">
										<h3>YOGESH KUMAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					
				</ul>
				
			</section>
			
            </div>
                
         </div>
		 <!--hc-->
				
				 <div role="tabpanel" class="tab-pane fade in " id="hc">
		    <div class="container_team">
			
		<hr/>
			<div class="heading">Hospitality committee</div>
			  
			    <section class="main">
			
				<ul class="ch-grid">
				  <li style="height:180px;width:180px;margin-right:60px;margin-bottom:40px;">
						<div class="ch-item ch-img-1" style="height:180px;width:180px;">				
							<div class="ch-info-wrap" style="height:180px;width:180px;">
								<div class="ch-info" style="height:180px;width:180px;">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/0.jpeg');"></div>
									<div class="ch-info-back">
										<h3 style="font-size: 24px;"><u>Chairman</u><br>VISHVAJEET PARIHAR</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/1.jpeg');"></div>
									<div class="ch-info-back">
										<h3>AKHILESH KUMAR</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/2.jpeg');"></div>
									<div class="ch-info-back">
										<h3>DIKSHA MUCHHALA</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/3.jpeg');"></div>
									<div class="ch-info-back">
										<h3>DISHA RAJ</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">				
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/4.jpeg');"></div>
									<div class="ch-info-back">
										<h3>HARI SINGH</h3>
										
									</div>	
								</div>
							</div>
						</div>
					</li>
					</ul>
					<ul class="ch-grid">
					<li>
						<div class="ch-item ch-img-1">
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/5.png');"></div>
									<div class="ch-info-back">
										<h3>LAL CHAND</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1">
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/15.jpeg');"></div>
									<div class="ch-info-back">
										<h3>Mritunjay</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/6.jpeg');"></div>
									<div class="ch-info-back">
										<h3>NEERAJ SINGH DHAKAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/7.jpeg');"></div>
									<div class="ch-info-back">
										<h3>NIKKI</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/8.jpeg');"></div>
									<div class="ch-info-back">
										<h3>OM PRAKASH</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/9.jpeg');"></div>
									<div class="ch-info-back">
										<h3>PREETI JATAV</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					</ul>
					<ul class="ch-grid">
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/10.jpeg');"></div>
									<div class="ch-info-back">
										<h3>ROHIT SINGH</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/11.jpeg');"></div>
									<div class="ch-info-back">
										<h3>SHERSINGH KUSHWAH</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/12.jpeg');"></div>
									<div class="ch-info-back">
										<h3>SHUBHAM PAWAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/13.jpeg');"></div>
									<div class="ch-info-back">
										<h3>VIJAY SINGH MAURYA</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					<li>
						<div class="ch-item ch-img-1" >
							<div class="ch-info-wrap">
								<div class="ch-info">
									<div class="ch-info-front ch-img-1" style="background-image:url('images/hc/14.jpeg');"></div>
									<div class="ch-info-back">
										<h3>VISHAL PATIDAR</h3>
										
									</div>
								</div>
							</div>
						</div>
					</li>
					</ul>
				
			</section>
			
            </div>
                
         </div>
				
	
         </div>
        </div>
		</div>
    </div>
</div>
</div>
		


        
                   <!-- menu Icon-->
   
				   
				   
				   
</div>

 <!--menu script and style-->
	

  <!--end menu-->


           		  <!-- end of section-->
			  
			  <!--script section-->
	   
	   	 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
      
            <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
	    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
	     <script  src="js/bubble_script.js"></script>
<script type="text/javascript" src="js/modernizr.custom.79639.js"></script> 
 
    </body>
</html>