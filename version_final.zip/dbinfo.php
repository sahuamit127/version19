<?php
$conn=mysqli_connect("localhost","root","","version19");
?>