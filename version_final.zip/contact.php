<html lang="en">
    <head>
		 <title>Version'19</title>
		 <link rel="icon" href="logo/logo.png" type="image/gif" sizes="16x16">
		     <meta http-equiv="X-UA-Compatible" content="IE=edge">
             <meta name="viewport" content="width=device-width, initial-scale=1">
		     
		
		    <!--style Section-->
			<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
 <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Iceland" />
              <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700%7CPoppins:400,500" rel="stylesheet">
 <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css'>
            <link href="http://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
	          <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700' rel='stylesheet' type='text/css'>
 
			  
	        
	          <link href="css/bubble_style.css" rel="stylesheet">
	          
		     <style type="text/css">

			body {
				background-image:url('img/background.png');
				margin: 0px;
				
				font-family:Monospace;
				font-size:13px;
				text-align:center;
				font-weight: bold;
				text-align:center;
			}

			a {
				color:#0078ff;
			}
            
			    canvas {
	position: absolute;
	top: 0;
	left: 0;
	z-index:100;
}
			
		</style>
		<style type="text/css">
        /* FontAwesome for working BootSnippet :> */

@import url('https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
#team {
   
}


section {
    padding: 60px 0;
}

section .section-title {
    text-align: center;
    color: #fff;
	font-family:iceland;
	font-size:48px;
    margin-bottom: 50px;
    text-transform: uppercase;
}

#team .card {
    border: none;
    background:#f1f4f6a3;
	box-shadow:2px 2px 6px 6px #8b88d7;
}






.frontside {
    position: relative;
    -webkit-transform: rotateY(0deg);
    -ms-transform: rotateY(0deg);
    z-index: 2;
    margin-bottom: 30px;
}



.frontside {
    -webkit-backface-visibility: hidden;
    -moz-backface-visibility: hidden;
    -ms-backface-visibility: hidden;
    backface-visibility: hidden;
    -webkit-transition: 1s;
    -webkit-transform-style: preserve-3d;
    -moz-transition: 1s;
    -moz-transform-style: preserve-3d;
    -o-transition: 1s;
    -o-transform-style: preserve-3d;
    -ms-transition: 1s;
    -ms-transform-style: preserve-3d;
    transition: 1s;
    transform-style: preserve-3d;
}

.frontside .card{
    min-height: 365px;
}



.frontside .card .card-title
 {
    color: #007b5e !important;
}

.frontside .card .card-body img {
    width: 120px;
    height: 120px;
    border-radius: 50%;
}
h4{
font-size:22px;
margin-top:17px;
font-weight:500;

}
h6{
margin-top:17px;
font-size:17px;font-weight:600;

}
    </style>
	 <script src="http://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	</head>
	
	
             <!--end of stylesheet section-->
		
	        <!--start body section-->
	
	<body>
		     <!-- content section-->
              <!--///////////////////////////////-->
			  <!--edge network background-->
             

              <div id="particles-js" style="position:fixed;"></div> 
 
            <script src="http://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
              <!-- Background small bubble -->
	        <div style="position:absolute;z-index:1001;top:3%;left:2%;">
								<a href="index.php">
								 <i class="fas fa-home" style="font-size:48px;color:#fff;"></i></a>
                                 </div>
                <div style="position:absolute;z-index:1000;height:100%;width:100%;text-align:left;">
                <section id="team" class="pb-5">
    <div class="container">
        <h5 class="section-title h1">Contact Us</h5>
        <div class="row">
            <!-- Team member -->
            <div class="col-xs-12 col-sm-6 col-md-3">
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="images/ccc/3.jpeg" alt="card image"></p>
                                    <h4 class="card-title">Ankur Jain</h4>
                                    <h6>Central Coordination Committee</h6>
									<h4>8818996634</h4>
									<h4>jainankur2000@gmail.com</h4>
                                </div>
                            </div>
                        </div>      
            </div>
            <!-- ./Team member -->
            <!-- Team member -->
            <div class="col-xs-12 col-sm-6 col-md-3">                    
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="images/eec/5.jpeg" alt="card image"></p>
                                    <h4 class="card-title">Kartik Gupta</h4>
                                    <h6>Event Execution Committee</h6>
                                    <h4>8009758874</h4>
									<h4>kartikgupta4994@gmail.com</h4>
                                </div>
                            </div>
                        </div>
            </div>
            <!-- ./Team member -->
            <!-- Team member -->
            <div class="col-xs-12 col-sm-6 col-md-3">
                       <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="images/prc/11.jpeg" alt="card image"></p>
                                    <h4 class="card-title">Sukhlal Ahirwar</h4>
                                    <h6>Public Relation Committee</h6>
									<h4>7047704796</h4>
									<h4>sukhi.ahirwar@gmail.com</h4>
                                    
                                </div>
                            </div>
                        </div>
            </div>
            <!-- ./Team member -->
            <!-- Team member -->
            <div class="col-xs-12 col-sm-6 col-md-3">  
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="images/hc/12.jpeg" alt="card image"></p>
                                    <h4 class="card-title">Shubham Pawar</h4>
                                    <h6>Hospitality<br> Committee</h6>
									<h4>9826425629</h4>
									<h4>Spawar111997@gmail.com</h4>
                                    
                                </div>
                            </div>
                        </div>
            </div>
            <!-- ./Team member -->
          
            <!-- ./Team member -->

        </div>
    </div>
</section>
<div id="reach" style="background:rgba(0,0,0,0.7);margin:5%;text-align:center;box-shadow:1px 1px 7px #9b9090;">
<span style="font-size:40px;width:100%;color:white;">How To Reach?</span>
<p style="font-size:20px;color:white;padding:5%;text-align:justify;font-family:arial;">
1.Tiruchirappalli is well connected by Air, Rail and Road
  network. NITT is situated in a place called THUVAKUDI on the northern side of
the Tiruchirappalli - Thanjavur road, 20 Kms away from Tiruchirappalli junction.
Tiruchirappalli junction is one of the important Railway junctions of Southern
Railways.<br><br>
2. All mofussil buses plying between Tiruchirappalli Central
Bus Stand and Thanjavur, stop at NIT Main Gate. (Tiruchirappalli Central Bus
Stand is about half a KM from Tiruchirappalli Railway Junction).
Town Bus No. 128 from Tiruchirappalli Central Bus Stand to Thuvakudi stops at NIT
Main Gate.<br><br>
3. A number of private Taxis, Call Taxis are available nearby
Tiruchirappalli Junction and Central Bus Stand. The approximate
Call Taxi fare from Tiruchirappalli Railway Station to NITT Main
Building will be about Rs.500/-<br><br>
4. If you are getting down at Chathiram Bus Stand/Main-Guard Gate
(Commercial Centre of Tiruchirappalli), number of town buses ply
between Chathiram Bus Stand/Main-Guard Gate and Thuvakudi.</p>
</div>
 <div style="text-align:center;padding-bottom:5px;">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.6827138709677!2d78.81103031551946!3d10.75891809233336!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3baa8d47758e1ae1%3A0xb3e16389eeab05a!2sNational+Institute+of+Technology+Tiruchirappalli!5e0!3m2!1sen!2sin!4v1561639773614!5m2!1sen!2sin"  frameborder="1" style="border:0;background:none;height:60%;width:90%;" allowfullscreen></iframe>


</div>            
				</div>
                   <!-- menu Icon-->
   
    

              <!-- end of section-->
			  
			  <!--script section-->
	    <script src="https://cdn.jsdelivr.net/gh/cferdinandi/smooth-scroll@15.0.0/dist/smooth-scroll.polyfills.min.js"></script>

	    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
    
	     <script  src="bubble_background.js"></script>
		 

 
    </body>
</html>