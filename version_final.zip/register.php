<html lang="en">
    <head>
		   <title>Version'19</title>
		 <link rel="icon" href="logo/logo.png" type="image/gif" sizes="16x16">
		     <meta http-equiv="X-UA-Compatible" content="IE=edge">
             <meta name="viewport" content="width=device-width, initial-scale=1">
		     <meta charset="utf-8">
		
		    <!--style Section-->
			  
			  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
              <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700%7CPoppins:400,500" rel="stylesheet">
              <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css'>
	          <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700' rel='stylesheet' type='text/css'>
			  <link rel="stylesheet" href="css/bootstrap.min.css">
			  <link rel='stylesheet' href='css/register.css'>
            <!--menu script and style-->
	           
              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
              <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
             
  <!--end menu-->
			  <link href="css/bubble_style.css" rel="stylesheet">
	          <style type="text/css">

			body {
				background-image:url('img/background.png');
				margin: 0px;
				
				font-family:Monospace;
				
				text-align:center;
				font-weight: bold;
				text-align:center;
			}

			a {
				color:#0078ff;
			}.heading{
			font-size:46px;
			font-weight:700;
			color:#fff;
			margin-top:4%;
			
			font-family:iceland;
			}
            
			    canvas {
	position: absolute;
	top: 0;
	left: 0;
	z-index:100;
}
			
		</style>
	</head>
	
	
             <!--end of stylesheet section-->
		
	        <!--start body section-->
	
	<body>
		     <!-- content section-->
              <!--///////////////////////////////-->
			  <!--edge network background-->
             

              <div id="particles-js" style="position:fixed;"></div> 
              
            <script src="http://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
              <!-- Background small bubble -->
			   <div style="position:absolute;z-index:1001;top:3%;left:2%;">
								<a href="index.php">
								 <i class="fas fa-home" style="font-size:48px;color:#fff;"></i></a>
                                 </div>
	         <div style="position:absolute;z-index:1000;height:100%;width:100%;text-align:center;">
			 <div class="heading">Registration</div>
			  <div class="row">
    <div class="col-xs-12 col-md-6" style="padding-top:8px;">
	 <div id="rules">
      <h1 style="font-family: Raleway;font-weight: bolder;">Instructions</h1><br>
	    <p style="font-size:20px;text-align:justify;">
        1.We provide free accommodation and food facilities for the duration of 2 days event.<br><br>
        2.Participants will have to bear with the traveling fares.<br><br>
        3.According to the norms of NITT, please do carry FORMALS with yourself.<br><br>
        </p>
      
	  </div>
    </div>
    <div class="col-xs-12 col-md-6" align="center">
          <form id="regForm" action="insert.php" method="post">
            <h1>Register</h1>
              <!-- One "tab" for each step in the form: -->
              <div class="tab">
                <p><input type="text" placeholder="College Name" oninput="this.className = ''" name="cname" required></p>
                <p><input type="text" placeholder="Your Name" oninput="this.className = ''" name="yname" required></p>
                <p><input type="email" placeholder="College E-mail" oninput="this.className = ''" name="cemail" required></p>
                <p><input type="password" placeholder="Password" oninput="this.className = ''" name="pwd" required></p>
                <p><input type="password" placeholder="Confirm Password" oninput="this.className = ''" name="cpwd" required></p>
                <p><input type="number" placeholder="College Contact" oninput="this.className = ''" name="cphone" required></p>
              </div>
              <div class="tab">
                 
                  <input type="number" id="member" name="member" value="" min="5" max="7" oninput="this.className = ''" placeholder="min. 5 and max. 7 members allowed" required><br>
                  <a href="#" id="filldetails" onclick="addFields()" style="color: orange;font-size:15px;">Fill Details</a>
                  <div id="info" style="font-size:15px;">
				  <!--dynamic textbox-->
				  
                  </div>
              </div>
              <div style="overflow:auto;">
                <div style="float:right;">
                  <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                  <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
                </div>
              </div>
              <!-- Circles which indicates the steps of the form: -->
              <div style="text-align:center;margin-top:10px;">
                <span class="step"></span>
                <span class="step"></span>
              </div>
          </form>
     </div>
  </div><script>
    var currentTab = 0; // Current tab is set to be the first tab (0)
    showTab(currentTab); // Display the current tab

    function showTab(n) 
    {
       // This function will display the specified tab of the form...
      var x = document.getElementsByClassName("tab");
      x[n].style.display = "block";
      //... and fix the Previous/Next buttons:
      if (n == 0) 
      {
        document.getElementById("prevBtn").style.display = "none";
      } 
      else 
      {
        document.getElementById("prevBtn").style.display = "inline";
      }
      if (n == (x.length - 1)) 
      {
        document.getElementById("nextBtn").innerHTML = "Submit";
      } 
      else
      {
        document.getElementById("nextBtn").innerHTML = "Next";
      } 
      //... and run a function that will display the correct step indicator:
      fixStepIndicator(n)
   }

   function nextPrev(n) 
   {
    // This function will figure out which tab to display
    var x = document.getElementsByClassName("tab");
    // Exit the function if any field in the current tab is invalid:
    if (n == 1 && !validateForm()) 
      return false;
    // Hide the current tab:
     x[currentTab].style.display = "none";
    // Increase or decrease the current tab by 1:
    currentTab = currentTab + n;
    // if you have reached the end of the form...
    if (currentTab >= x.length) 
    {
      // ... the form gets submitted:
      document.getElementById("regForm").submit();
      return false;
    }
     // Otherwise, display the correct tab:
    showTab(currentTab);
   }

function validateForm() 
{
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) 
  {
    // If a field is empty...
    if (y[i].value == "") 
    {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) 
  {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) 
{
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) 
  {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class on the current step:
  x[n].className += " active";
}

function addFields(){
            // Number of inputs to create
            var number = document.getElementById("member").value;
            // Container <div> where dynamic content will be placed
            var container = document.getElementById("info");
            // Clear previous contents of the container
            while (container.hasChildNodes()) {
                container.removeChild(container.lastChild);
            }
			if(number>=5 &&number<=7)
			{
            for (i=0;i<number;i++){
                // Append a node with a random text
                container.appendChild(document.createTextNode("Member Name " + (i+1)));
                // Create an <input> element, set its type and name attributes
                var input = document.createElement("input");
                input.type = "text";
                input.name = "member" + i;
                container.appendChild(input);
                // Append a line break 
                container.appendChild(document.createElement("br"));

                container.appendChild(document.createTextNode("Contact Detail" + (i+1)));
                // Create an <input> element, set its type and name attributes
                var input = document.createElement("input");
                input.type = "number";
                input.name = "Contact" + i;
                container.appendChild(input);
                // Append a line break 
                container.appendChild(document.createElement("br"));
                container.appendChild(document.createElement("br"));
            }}
        }
	
</script>		 
			 
			 </div>
                        
                       

                        


						
                   <!-- menu Icon-->
  

    

              <!-- end of section-->
			  
			  <!--script section-->
	    <script src="https://cdn.jsdelivr.net/gh/cferdinandi/smooth-scroll@15.0.0/dist/smooth-scroll.polyfills.min.js"></script>

	    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
         
	     <script  src="bubble_background.js"></script>
		 
		  
 
    </body>
</html>