var dis =  5;
function myFunction(x) {
      x.classList.toggle("change");
   if(dis==5){
   document.getElementById("menu_container").style.background = "#fff";
  document.getElementById("menu_container").style.height = "57%";
  document.getElementById("menu_container").style.width = "26%";

  document.getElementById("menu_item_container").style.display = "block";
 document.getElementById("menu_item_container").style.WebkitTransitionDelay = "all 2s"; // Code for Safari 3.1 to 6.0
  document.getElementById("menu_item_container").style.TransitionDelay = "all 2s";
 
 dis=8;
}
else
{

  document.getElementById("menu_container").style.height = "20px";
  document.getElementById("menu_container").style.width = "20px";
 document.getElementById("menu_container").style.background = "none";
 document.getElementById("menu_item_container").style.display = "none";

  
  dis=5;
    document.getElementById("menu_container").style.WebkitTransition = "all 1s"; // Code for Safari 3.1 to 6.0
  document.getElementById("menu_container").style.transition = "all 1s";
}


}