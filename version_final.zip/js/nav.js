const scroll = new SmoothScroll('a[href*="#"]', {
  easing: 'easeInOutQuint',
  speed: 700,
  speedAsDuration: true,
  clip: true,
  offset: 10 
});

const hamburger = document.querySelector('.hamburger');
const navList = document.querySelector('.navigation-list');
const navLinks = document.querySelectorAll('.nav-links');
const overlay1 = document.querySelector('#overlay1');
const socialLinks = document.querySelector('#social-links');
let opened = false;

function addActive(element) {
  element.classList.add('active');
}
function removeActive(element) {
  element.classList.remove('active');
}

hamburger.addEventListener('click', () => {
  if(!opened) {
    addActive(hamburger);
    addActive(navList);
    addActive(socialLinks);
    for(let i = 0; i < navLinks.length; i++) {
      addActive(navLinks[i]);
     }
    overlay1.classList.add('nav-is-active');
    opened = true;
   } else {
      removeActive(hamburger);
      removeActive(navList);
      removeActive(socialLinks);
      for(let i = 0; i < navLinks.length; i++) {
        removeActive(navLinks[i]);
      }
      overlay1.classList.remove('nav-is-active');
      navList.classList.add('close-nav');
      opened = false;
    }
});

navList.addEventListener('click', (event) => {
  if(event.target.tagName === 'A') {
    removeActive(hamburger);
    removeActive(navList);
    removeActive(socialLinks);
    overlay1.classList.remove('nav-is-active');
    for(let i = 0; i < navLinks.length; i++) {
      removeActive(navLinks[i]);
    }
    navList.classList.add('close-nav');
  }
  opened = false;
});