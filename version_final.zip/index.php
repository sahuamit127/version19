<html lang="en">
    <head>
		 <title>Version'19</title>
		 <link rel="icon" href="logo/logo.png" type="image/gif" sizes="16x16">
		     <meta http-equiv="X-UA-Compatible" content="IE=edge">
             <meta name="viewport" content="width=device-width, initial-scale=1">
		     <meta charset="utf-8">
		
		    <!--style Section-->
			<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
                  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Iceland" />
              <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700%7CPoppins:400,500" rel="stylesheet">
 <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css'>

	          <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,700' rel='stylesheet' type='text/css'>
 <!--menu script and style-->
 		<link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css" rel="stylesheet" />
   <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
      <link rel="stylesheet" href="css/center_lines.css">	
	<link rel="stylesheet" href="css/menu/spinkit.css">	
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
<script type="text/javascript" src="js/menu/app.js"></script>
  <script type="text/javascript" src="js/menu/spinkit.js"></script>
  <!--end menu-->
			   <link rel="stylesheet" href="css/timer.css">
	        
	          <link href="css/bubble_style.css" rel="stylesheet">
	          
		     <style type="text/css">

			body {
				background-image:url('img/background.png');
				margin: 0px;
				
				font-family:Monospace;
				font-size:13px;
				
				font-weight: bold;
				text-align:center;
			}

			a {
				color:#0078ff;
			}
            
			    canvas {
	position: absolute;
	top: 0;
	left: 0;
	z-index:100;
                       }
.mcalogo{
height:43px;width:175px;padding-left:5%;margin-top:0.5%;
float:left;

}
.versionlogo{
width:100%;padding-top:4%;padding-bottom:23%;padding-left:6%;

}
.versionlogo img{
height:100px;width:400px;

}

.nittlogo
{
height:110px;width:110px;float:right;padding-right:0.5%;padding-top:0.5%;

}
@media only screen and (max-width:500px) {
.nittlogo
{
height:80px;width:80px;float:right;padding-right:0.5%;padding-top:0.5%;

}
.text{
font-size:20px;
}
.mcalogo{
display:none;

}
.versionlogo {
width:100%;padding-top:23%;padding-bottom:10%;padding-left:2%;

}

.versionlogo img{
height:50px;width:200px;

}
}
			
		</style>
<script type="text/javascript" async="" src="https://ssl.google-analytics.com/ga.js"></script>
	</head>
	
	
             <!--end of stylesheet section-->
		
	        <!--start body section-->
	
	<body>
	
		     <!-- content section-->
              <!--///////////////////////////////-->
			  <!--edge network background-->
             <canvas id=c></canvas>
           <div id="particles-js" ></div> 
 
            <script src="http://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
              
            <div id="myscene" style="position:absolute;z-index:10001;width:100%;">

              <!-- Background small bubble -->
	        
			   <?php
session_start();
if(isset($_SESSION['cname']))
{	
  ?>   <script>swal("college name is not valid")</script><?php
	unset($_SESSION['cname']);
}
if(isset($_SESSION['yname']))
{	
  ?>   <script>swal("your name si not valid")</script><?php
	unset($_SESSION['message1']);
}
if(isset($_SESSION['email']))
{	
  ?>   <script>swal("wrong email")</script><?php
	unset($_SESSION['email']);
}
  if(isset($_SESSION['message']))
{	
  ?>   <script>swal("password unmatched")</script><?php
	unset($_SESSION['message']);
}
if(isset($_SESSION['message1']))
{	
  ?>   <script>swal("Registered Succesfully")</script><?php
	unset($_SESSION['message1']);
}if(isset($_SESSION['message11']))
{	
  ?>   <script>swal("Server Interrupt")</script><?php
	unset($_SESSION['message11']);
}
if(isset($_SESSION['cno']))
{	
  ?>   <script>swal("Server Interrupt")</script><?php
	unset($_SESSION['cno']);
}
    ?>

			

                            <div style="width:100%;" >
						            <img src="img/mcalogo.png"  class="mcalogo">   
                                   <img src="img/logo.png" class="nittlogo">
	                   		
							</div>	<br>	   
                        <div class="versionlogo">
		                   
			             <img src="img/version_white.png" />
			                
			            </div> 
                         <div class="center_lines">
                                  <div class="text" ></div>
                         </div>

                        <div class="timer_container">
                           <ul class="timer">
                            <li class="li-box"><span id="days"></span>days</li>
								<li class="li-box"><span id="hours"></span>Hours</li>
									<li class="li-box"><span id="minutes"></span>Minutes</li>
										<li class="li-box"><span id="seconds"></span>Seconds</li>
							</ul>
						</div>


						
                   <!-- menu Icon-->
   <div class="site-nav-animation-wrapper menu-animation-wrapper">
      <div class="site-nav-animated-background menu-animated-background"></div>
    </div>
    <a href="#" class="menu menu-white menu-spinkit" style="position:fixed;">
      <span class="menu-icon-line-1 menu-icon-line"></span>
      <span class="menu-icon-line-2 menu-icon-line"></span>
      <span class="menu-icon-line-3 menu-icon-line"></span>
    </a>

    <div class="site-nav-overlay js-nav">
      <div class="nav-content">
        <div class="js-nav-header nav-header">
          <span class="nav-header-text">Version'19</span>
          <div class="nav-header-line js-nav-header-line"></div>
        </div>

        <ul class="nav-categories">
          <li class="nav-category js-nav-animate"><a href="#" class="nav-link">Home</a></li>
          <li class="nav-category js-nav-animate"><a href="event.php" class="nav-link">Event</a></li>
          <li class="nav-category js-nav-animate"><a href="team.php" class="nav-link">Teams</a></li>
          <li class="nav-category js-nav-animate"><a href="contact.php" class="nav-link">Contact</a></li>
		  <li class="nav-category js-nav-animate"><a href="about.php" class="nav-link">About</a></li>
		  <li class="nav-category js-nav-animate"><a href="gallery.php" class="nav-link">Gallery</a></li>
		  <li class="nav-category js-nav-animate"><a href="register.php" class="nav-link">Registration</a></li>
        </ul>

        <div class="nav-sublinks js-nav-animate">
          <div class="js-nav-animate">
          <a class="nav-link nav-sublink" target="_blank" href="https://www.facebook.com/versionmeet/"><i class="fab fa-facebook-f"></i></a>
          <a class="nav-link nav-sublink" target="_blank" href="https://www.youtube.com/channel/UCtD7JZ4zH72M8lSzo1y89gQ"><i class="fab fa-youtube"></i></a>
          <a class="nav-link nav-sublink" target="_blank" href="https://www.instagram.com/version_nit_trichy/"><i class="fab fa-instagram"></i></a>
          </div>
        </div>
      </div>

    </div>
	
	
	<!--footer Section-->
	<div style="position:fixed;bottom:1%;color:#fff;width:100%;text-align:center;font-size:15px;">
	
	
	Made With ❤️ By EEC.
	
	
	
         </div>
    </div>
		<script type="text/javascript">
		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-86951-7']);
		  _gaq.push(['_trackPageview']);
 
		  (function() {
		    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		    (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(ga);
		  })();
		</script>

		<script type="text/javascript" src="js/three.min.js"></script>
		<script type="text/javascript" src="js/Detector.js"></script>

		<script id="vs" type="x-shader/x-vertex">

			varying vec2 vUv;

			void main() {

				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

			}

		</script>

		<script id="fs" type="x-shader/x-fragment">

			uniform sampler2D map;

			uniform vec3 fogColor;
			uniform float fogNear;
			uniform float fogFar;

			varying vec2 vUv;

			void main() {

				float depth = gl_FragCoord.z / gl_FragCoord.w;
				float fogFactor = smoothstep( fogNear, fogFar, depth );

				gl_FragColor = texture2D( map, vUv );
				gl_FragColor.w *= pow( gl_FragCoord.z, 20.0 );
				gl_FragColor = mix( gl_FragColor, vec4( fogColor, gl_FragColor.w ), fogFactor );

			}

		</script>

		<script type="text/javascript">

			if ( ! Detector.webgl ) Detector.addGetWebGLMessage();

			var container;
			var camera, scene, renderer;
			var mesh, geometry, material;

			var mouseX = 0, mouseY = 0;
			var start_time = Date.now();

			var windowHalfX = window.innerWidth / 2;
			var windowHalfY = window.innerHeight / 2;

			init();

			function init() {

				container = document.createElement( 'div' );
				document.body.appendChild( container );

				// Bg gradient

				var canvas = document.createElement( 'canvas' );
				canvas.width = 32;
				canvas.height = window.innerHeight;

				var context = canvas.getContext( '2d' );

				var gradient = context.createLinearGradient( 0, 0, 0, canvas.height );
				gradient.addColorStop(0, "#1e4877");
				gradient.addColorStop(0.5, "#4584b4");

				context.fillStyle = gradient;
				context.fillRect(0, 0, canvas.width, canvas.height);

				container.style.background = 'url(' + canvas.toDataURL('image/png') + ')';
				container.style.backgroundSize = '32px 100%';

				//

				camera = new THREE.PerspectiveCamera( 30, window.innerWidth / window.innerHeight, 1, 3000 );
				camera.position.z = 6000;

				scene = new THREE.Scene();

				geometry = new THREE.Geometry();

				var texture = THREE.ImageUtils.loadTexture( 'cloud10.png', null, animate );
				texture.magFilter = THREE.LinearMipMapLinearFilter;
				texture.minFilter = THREE.LinearMipMapLinearFilter;

				var fog = new THREE.Fog( 0x4584b4, - 100, 3000 );

				material = new THREE.ShaderMaterial( {

					uniforms: {

						"map": { type: "t", value: texture },
						"fogColor" : { type: "c", value: fog.color },
						"fogNear" : { type: "f", value: fog.near },
						"fogFar" : { type: "f", value: fog.far },

					},
					vertexShader: document.getElementById( 'vs' ).textContent,
					fragmentShader: document.getElementById( 'fs' ).textContent,
					depthWrite: false,
					depthTest: false,
					transparent: true

				} );

				var plane = new THREE.Mesh( new THREE.PlaneGeometry( 64, 64 ) );

				for ( var i = 0; i < 8000; i++ ) {

					plane.position.x = Math.random() * 1000 - 500;
					plane.position.y = - Math.random() * Math.random() * 200 - 15;
					plane.position.z = i;
					plane.rotation.z = Math.random() * Math.PI;
					plane.scale.x = plane.scale.y = Math.random() * Math.random() * 1.5 + 0.5;

					THREE.GeometryUtils.merge( geometry, plane );

				}

				mesh = new THREE.Mesh( geometry, material );
				scene.add( mesh );

				mesh = new THREE.Mesh( geometry, material );
				mesh.position.z = - 8000;
				scene.add( mesh );

				renderer = new THREE.WebGLRenderer( { antialias: false } );
				renderer.setSize( window.innerWidth, window.innerHeight );
				container.appendChild( renderer.domElement );

				document.addEventListener( 'mousemove', onDocumentMouseMove, false );
				window.addEventListener( 'resize', onWindowResize, false );

			}

			function onDocumentMouseMove( event ) {

				mouseX = ( event.clientX - windowHalfX ) * 0.25;
				mouseY = ( event.clientY - windowHalfY ) * 0.15;

			}

			function onWindowResize( event ) {

				camera.aspect = window.innerWidth / window.innerHeight;
				camera.updateProjectionMatrix();

				renderer.setSize( window.innerWidth, window.innerHeight );

			}

			function animate() {

				requestAnimationFrame( animate );

				position = ( ( Date.now() - start_time ) * 0.03 ) % 8000;

				camera.position.x += ( mouseX - camera.position.x ) * 0.01;
				camera.position.y += ( - mouseY - camera.position.y ) * 0.01;
				camera.position.z = - position + 8000;

				renderer.render( scene, camera );

			}

		</script>
		<div style="background: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAHMCAYAAAC0i6q5AAADBElEQVR4Xu3SZ1YTYBQGYdmIiJFiQAFFxEiIGDzHCopgQVEQ6b0TSIAA9t57773uT5cxP765K5jz3Ddn9e7pf6vAyzGAF9gzA2+ADsg1YG+K3UCuAftm2ResMQAX2D8HbyD4gDxaIO9Amt2AAbxAfYbdwFoD6ufhFzSEHhChBSINC+wGIgcNoAUOLbIbWGcALtCYhTcQfEB+4xL7gvzDBuACy/AGmuCAAgOaVtgNFDQbAAsUNp9jN1B4xABa4Oh5eAN0QBEfcIF9QdExA3CBi+wG1h83ABe4BG+gJfSAKC0QbbnMbiB6woAr9AvggOKTBlxlN1DcagAsUNJ6jd1AySkDcIHr7AY2nDbgBv0COqAt9ICNbTfZDfAB7bQAH3AL3kA7HFB6xoDb7AZKOwyABco67rAbKDtrwF36BXRAJxxQzgfcYzdQ3kkHdBlwn93Api46oNuAB/AGuumAHjhgc89D9gV8QC8twAc8gjfQCwdU9BnwmN1ARR8d0B96wJb+J+wG+IABWoAPeApvYAAOqBzEA56xL6gcDD5gCBbYOvSc3QAfMEwL8AEv4A0MwwFVIwa8ZDdQNUIHjOIBr9gXbBsNPmCMFhh7DW8g+IDYOPyC2PgbdgMGxCboF0y8ZTewHQ+YpAUm38EvMGAKfkH11Ht2AwZUT9MvmP4Ab4AOiOMBM/AL4jMf2Q0YEE/BL6hJfWI3YEDN7Gf4BcEHJGiBxNwXdgMGJNL0C9Jf2Q3sMCBDvyDzDd4AHVCLB8x/Z19QawAusPCD3cBOA3CBxZ/wBoIPSGbhFySzv9gNGJBc+g2/gA6oM2D5D7uBOgNogV0rf9kNGKCAAgoooIACCiiggAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACCiiggAIKKKCAAgoooIACCiiggAIKKKCAAgoooAAt8B8H4i+kZeb4TQAAAABJRU5ErkJggg==&quot;) 0% 0% / 32px 100%;"><canvas style="width: 100%; height:100%;">
		</canvas></div>
              <!-- end of section-->
			  
			  <!--script section-->
	    <script src="https://cdn.jsdelivr.net/gh/cferdinandi/smooth-scroll@15.0.0/dist/smooth-scroll.polyfills.min.js"></script>

	    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
         <script  src="js/edge_script.js"></script>
	     <script  src="bubble_background.js"></script>
		 <script  src="js/center_lines.js"></script>
		  <script  src="js/timer.js"></script>
 
    </body>
</html>