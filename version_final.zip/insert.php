<?php
session_start();
include('dbinfo.php');
$cnameErr="" ;$ynameErr="" ;$emailErr=""; $cnoErr="" ;$pswErr="";
function filterName($field)
 {
    $field = filter_var(trim($field), FILTER_SANITIZE_STRING);
    if(filter_var($field, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+/")))){
        return $field;
    }else{
        return FALSE;
    }
}
function filtercontact($field)
{
    $field = filter_var(trim($field), FILTER_SANITIZE_STRING);
    if(filter_var($field, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[0-9]{10}+$/")))){
        return $field;
    }else{
        return FALSE;
    }
} 
function filterEmail($field)
{
    $field = filter_var(trim($field), FILTER_SANITIZE_EMAIL);
     if(filter_var($field, FILTER_VALIDATE_EMAIL)){
        return $field;
    }else{
        return FALSE;
    }
}
$cname=$email=$yname=$cno=$pwd="";
if($_SERVER["REQUEST_METHOD"] == "POST")
{
 if(empty($_POST["cname"]))
  {      $cnameErr= $_SESSION["cname"] = "Please enter your name.";
      header("location:register.php");
    }else{
        $cname = filterName($_POST["cname"]);
        if($cname == FALSE){
            $cnameErr=$_SESSION["cname"] = "Firstname must have alphabet characters only.";
          header("location:register.php");
        }
  }
    if(empty($_POST["yname"]))
  {    $ynameErr= $_SESSION["yname"] = "Please enter your name.";
      header("location:register.php");
    }else{
        $yname = filterName($_POST["yname"]);
        if($yname == FALSE){
            $ynameErr=$_SESSION["yname"] = "Firstname must have alphabet characters only.";
          header("location:register.php");
        }
  }
  if(empty($_POST["cemail"]))
    {
           $emailErr=$_SESSION["email"] = "Please enter email.";
        header("location:register.php");
    }else{
        $email = filterEmail($_POST["cemail"]);
        if($email == FALSE){
      $emailErr= $_SESSION["email"] = "Please enter a valid email.";
        header("location:register.php");
        }
    }
     if(empty($_POST["cphone"]))
  {   $cnoErr=$_SESSION["cno"] = "Please enter your name.";
        header("location:register.php");
    }else{
        $cno = filtercontact($_POST["cphone"]);
        if($cno == FALSE){
             $cnoErr=$_SESSION["cno"] = "Firstname must have alphabet characters only.";
            header("location:register.php");
        }
      }
         if(empty($_POST["pwd"]))
  {        $pswErr=$_SESSION["pwd"] = "Please enter your name.";
       header("location:register.php");
    }
	else{
		
		$pwd=$_POST["pwd"];
	}
	
}
   if( $cnameErr=="" &&  $ynameErr=="" &&  $emailErr==""  && $cnoErr=="" && $pswErr=="")
 {
  
  if($_POST["pwd"]!=$_POST["cpwd"])
		{
			$_SESSION["message"]="Password does not match.";
			header("location:register.php");
		}
			else{
		$sql="INSERT INTO college_detail (college_name,your_name,college_email,password,contact) VALUES ('".$cname."','".$yname."','".$email."','".$pwd."','".$cno."')";
	         $res=mysqli_query($conn,$sql);
		if($res)
		{
			extract($_POST);
			  for($i=0;$i<$member;$i++)
		   {
			   ${'sql'.$i}="INSERT INTO  team_detail(college_name,member,contact) values ('".$cname."','".${'member'.$i}."','".${'Contact'.$i}."')";
			   ${'res'.$i}=mysqli_query($conn,${'sql'.$i});
		   }
		   
		   if($res1)
		   {
		  $_SESSION["message1"]="Registered Successfully. ";
			header("location:index.php");
		}
			
			
			
			
		
		}
		else
		{
		$_SESSION["message11"]="<h3>SERVER INTERUPTED</h3>".mysql_error();
				header("location:register.php");
		}
		
		
		}
  
 }else{
	 $_SESSION["message1231"]="Registered Successfully. ";
			header("location:register.php");
 }
 
  ?>
  
  