<html lang="en">
    <head>
		  <title>Version'19</title>
		 <link rel="icon" href="logo/logo.png" type="image/gif" sizes="16x16">
		     <meta http-equiv="X-UA-Compatible" content="IE=edge">
             <meta name="viewport" content="width=device-width, initial-scale=1">
		     <meta charset="utf-8">
		
		    <!--style Section-->
			  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

              <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Iceland" />
              <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	          <link href="css/nav.css" rel="stylesheet">
			  <link href="css/animate.css" rel="stylesheet">
			  <link href="css/event_popup.css" rel="stylesheet">
			  <link href="css/animate.min.css" rel="stylesheet">
	        		  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
                       <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
					    <!--menu script and style-->
	<link rel="stylesheet" href="css/menu/spinkit.css">	
  <script src="js/jquery/version1.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
<script type="text/javascript" src="js/menu/app.js"></script>
  <script type="text/javascript" src="js/menu/spinkit.js"></script>
  <!--end menu-->
	          <link href="style.css" rel="stylesheet">
	          
		     <style type="text/css">

			body {
				background-color: #04031e;
				margin: 0px;
				
				font-family:Monospace;
				font-size:13px;
				text-align:center;
				font-weight: bold;
				text-align:center;
			}

			a {
				color:#0078ff;
			}
            .heading{
			font-size:60px;
			font-weight:700;
			color:#fff;
			margin-top:3%;
			margin-bottom:8%;
			font-family:iceland;
			}
			html {
  box-sizing: border-box;
  font-size: 62.5%;
}

*,
*:before,
*:after {
  margin: 0px;
  padding: 0;
  box-sizing: inherit;
}



.event_container {
  max-width: 1200px;
  margin: 0 auto;
}
@media only screen and (max-width:500px) {

.heading{
margin-top:15%;
}

.event_container {
  
  margin-bottom:10px; 
}
}
.item-container {
  display: grid;
  margin-top: 3rem;
  grid-gap: 2rem;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
}
.item-container a {
  text-decoration: none;
 
}

.item {
  position: relative;
  padding: 3rem 2rem;
  border-radius: 6px;
  background-color: #e668a7;
  display: block;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  box-shadow: 0px 0px 20px 0px rgba(95, 140, 191, 0.9);
 
}

a:nth-child(1) > .item {
  background-color: #647acb;
}

a:nth-child(2) > .item {
  background-color: #7c5e10;
}

a:nth-child(3) > .item {
  background-color: #2186eb;
}

a:nth-child(4) > .item {
  background-color: #e67635;
}

a:nth-child(5) > .item {
  background-color: #7bb026;
}

a:nth-child(6) > .item {
  background-color: #f7c948;
}

a:nth-child(7) > .item {
  background-color: #31b237;
}

a:nth-child(8) > .item {
  background-color: #cf1124;
}

.emoji {
  font-size: 10rem;
  
}

.item-hover {
  background-color: #000000cc;
  font-weight: bold;
  color: #fff;
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;

  flex-direction: column;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.3s;
  border-radius: 6px;
}
.item-hover:hover {
  opacity: 1;
}

.tag {
  font-size: 1rem;
  text-transform: uppercase;
  margin-top: 1rem;
  padding: 0.7rem 1rem;
  color: #000;
  background-color: #fff;
  border-radius: 20px;
}
.bapu{
grid-template-columns: 285px 285px 285px;justify-content:center;

}
.bapu1{
grid-template-columns: 285px 285px;justify-content:center;

}
@media only screen and (max-width:500px) 
{
.bapu{
grid-template-columns: 285px;

}
.bapu1{
grid-template-columns: 285px;
}

}



		</style>
	</head>

	
             <!--end of stylesheet section-->
		
	        <!--start body section-->
	
	<body>
		     <!-- content section-->
              
  
			  
			  
			  <!-- event 1-->
          <div class="modal fade" id="ev1" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Phoenix</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab1', this, '#777')" id="de1" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules1', this, '#777')" >Rules</button>

					<div id="ab1" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br> Exhibit The Competence</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;">It's not an event , it's a test of fire. It's not a competition, it's survival of the fittest.
It's not about winning, it's about conquering.<br> THE PHOENIX an event to dare for,
to die for and to live for. Permanence, perseverance and persistence in spite of all
obstacles, discouragement, and impossibilities: It is this , that in all things
distinguishes the strong soul from the weak. It's a battle of wits, words and wills.</p>
					    <br><br>
					    </p>
					    <br>
					    	</div>

					<div id="rules1" class="tabcontent">
						
							
								<h2 style="text-align:center;color:#393b8e;"><br> Exhibit The Competence</h2><br>	
								<p style="color:#000;font-size:20px;text-align:justify;">
										</p> 
					</div>
			</div>
            </div>
            </div>
          </div>
             <!--event 2-->
			 <div class="modal fade" id="ev2" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Mind Matrix</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab2', this, '#777')" id="de2" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules2', this, '#777')" >Rules</button>

					<div id="ab2" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br> Crack the puzzle, win the battle !!!!</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;">‘’Alone we can do so little; together we can do so much’’.
This is the event where you use your brain to solve the puzzle with team efforts.
This event requires individual’s logical thinking, creativity, intelligence, reasoning
power to solve the different puzzles to clear the every stage to the ‘path of
victory’.
So “Have patience just like a puzzle till you reach NIT TRICHY”. </p>
					    <br><br>
					    </p>
					    <br>
					    	</div>

					<div id="rules2" class="tabcontent">
						<h3></h3>
						<h2 style="text-align:center;color:#393b8e;"><br> Crack the puzzle, win the battle !!!!</h2><br>
							<p style="color:#000;font-size:20px;text-align:justify;">
									
									1.No. of participant: - 3<br>
                                    2.only 1 team per college is permitted.<br>
                                    3.Any malpractice will lead to the disqualification of the team. <br>
							</p> 
					</div>
			</div>
            </div>
            </div>
          </div>
		  <!--event 3-->
		  <div class="modal fade" id="ev3" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Technothon</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab3', this, '#777')" id="de3" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules3', this, '#777')" >Rules</button>

					<div id="ab3" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br>Think innovative and make it possible</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;">We are Surrounded by several problems, but have you ever tried to solve them.<br>

It's a project submission round in which participants will be asked to solve a real life problem.<br>

Projects will be evaluated on 2 days prior of Version 2019 and once again a final review will be done on Day 1 of Version 19.<br>

The theme or topic of the project will be posted on the website 30 days before and an email will be sent to the participating teams too.
 </p>
					    <br><br>
					    </p>
					    <br>
					    	</div>

					<div id="rules3" class="tabcontent">
						<h3></h3>
						<h2 style="text-align:center;color:#393b8e;"><br>Think innovative and make it possible</h2><br>	
							<p style="color:#000;font-size:20px;text-align:justify;">
								
									1. One project from each college will be accepted.<br>
                                    2. Copied Solution will not be accepted.<br>
                                    3. Judge’s decision will be final.<br>
                                    4. Only one team per college will be permitted.<br>
							</p> 
					</div>
			</div>
            </div>
            </div>
          </div>
		  <!--event 4-->
		  <div class="modal fade" id="ev4" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Gamers Eden</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab4', this, '#777')" id="de4" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules4', this, '#777')" >Rules</button>

					<div id="ab4" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br>New Dimension of Battle.</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;">I don't need to get a life, I'm a gamer, I have lots of lives!'
When the rifle is loaded and helmet is on. The arena yearns a winner from dusk to
dawn. Step into the combat zone and let out your skill. 
Team up or be solitary, you know the drill. You have to face the bests
in the business and then win to be crowned victor.</p>
 <br><br>
					    </p>
					    <br>
					   		</div>

					<div id="rules4" class="tabcontent">
						<h3></h3>
						<h2 style="text-align:center;color:#393b8e;"><br>New Dimension of Battle.</h2><br>	
							<p style="color:#000;font-size:20px;text-align:justify;">
								
									<u>CS</u><br>

1.	There will be a team of 5 from each college.<br>

2.	There will be a knife round for toss that which team will be terrorist and which will be Counter terrorist.<br>

3.	There will be each round of 1:55 minutes.<br>

4.	800 dollar will be provided as Starting money.<br>

5.	There will be 5 Counter terrorist and 5 terrorist.<br>

6.	In cash of tie, it will be chance for terrorist.<br>

7.	Each round will be knockout round.<br><br>




<u>FIFA</u><br>

1.	There will be 4 minute half in each game.<br>

2.	Each game will be a knockout game.<br>

3.	In case of tie there will be a penalty shoot out.<br>

4.	Final may have 1 or 2 lap, it will be decided at that time only.<br>

5.	There will extra time in final.
 

							</p> 
					</div>
			</div>
            </div>
            </div>
          </div>
		  <!--event 5-->
		  <div class="modal fade" id="ev5" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Enquizita</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab5', this, '#777')" id="de5" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules5', this, '#777')" >Rules</button>

					<div id="ab5" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br>Assemble the jumble</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;">Does the sound of puzzles and problems get you excited? One ,who enjoys getting
into the mystery of puzzles and cracking it,will enjoy this event the most. This
event will check your logical and critical thinking and little bit knowledge would be
expected from the participants.</p> <br><br>
					    </p>
					    <br>
					    	</div>

					<div id="rules5" class="tabcontent">
						<h3></h3>
						<h2 style="text-align:center;color:#393b8e;"><br>Assemble the jumble</h2><br>
							<p style="color:#000;font-size:20px;text-align:justify;">
									
									1.Each team will be allotted 20 minutes.<br>
                                  2.Use of pen and paper is strictly prohibited.<br>
                                  3.It will be final round, there will be no prelims.<br>
                                  4.Teams involving in any malpractices will be disqualified.<br>
                                  5.Judges Decision will be final decision.
							</p> 
					</div>
			</div>
            </div>
            </div>
          </div>
		  <!--event 6-->
		  <div class="modal fade" id="ev6" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Mind Shuffler</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab6', this, '#777')" id="de6" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules6', this, '#777')" >Rules</button>

					<div id="ab6" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br>“Make it work, make it right, make it fast.”</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;">This competition presents challenges for you to show your logical coding skills. So
if you get the adrenaline rush when you see a difficult problem, then this is
definitely for you. Speed, Accuracy and Efficiency matters at last.
There will be two rounds for this event</p>  <br><br>
					    </p>
					    <br>
					</div>

					<div id="rules6" class="tabcontent">
						<h3></h3>
						<h2 style="text-align:center;color:#393b8e;"><br>“Make it work, make it right, make it fast.”</h2><br>	
							<p style="color:#000;font-size:20px;text-align:justify;">
								
								  1. Each team has two participants.<br>
                                  2. Participants are not allowed to add or remove any line from given code.That
                                     means, no writing or editing will be allowed.<br>
                                  3. Participants are only allowed to move the block of code.<br>
                                  4. A ranking will be created based on the points scored. Someone with more
                                     points will be higher in the ranking than someone with less point.<br>
                                  5. If two participants have the same number of points, then the total time is
                                     considered. The one with lesser total time will be higher in the ranking order.<br>
                                  6. In case of any malpractices,the respective team will be disqualified from the
                                     event.
                           </p> 
					</div>
			</div>
            </div>
            </div>
          </div>
		  <!--event 7-->
		  <div class="modal fade" id="ev7" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Mystery Maze</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab7', this, '#777')" id="de7" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules7', this, '#777')" >Rules</button>

					<div id="ab7" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br> Discover the undiscovered</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;">Move until you don't find it because it's a game of roaming. Don't get tired
because your looseness will make other winner</p> <br><br>
					    </p>
					    <br>
						</div>

					<div id="rules7" class="tabcontent">
						<h3></h3><h2 style="text-align:center;color:#393b8e;text-align:justify;"><br> Discover the undiscovered</h2><br>	
							<p style="color:#000;font-size:20px;text-align:justify;">
								
									1. A max of 4 members are allowed in a team.<br>
                                    2. Judge’s decision will be final.<br>
                                    3. Only one team per college will be permitted. <br>
							</p> 
					</div>
			</div>
            </div>
            </div>
          </div>
		  <!--event 8-->
		  <div class="modal fade" id="ev8" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Event X</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab8', this, '#777')" id="de8" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules8', this, '#777')" >Rules</button>

					<div id="ab8" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br>Snap Into Network!</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;"> A surprise event</p><br><br>
					    </p>
					    <br>
					</div>

					<div id="rules8" class="tabcontent">
						<h3></h3>
						<h2 style="text-align:center;color:#393b8e;"><br>Snap Into Network!</h2><br>
							<p style="color:#000;font-size:20px;text-align:justify;">
									
									A surprise event
							</p> 
					</div>
			</div>
            </div>
            </div>
          </div>
		  <!--event 9-->
		  <div class="modal fade" id="ev9" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Code Chamber</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab9', this, '#777')" id="de9" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules9', this, '#777')" >Rules</button>

					<div id="ab9" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br>Stay till end, eliminate other or leave it</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;">An Event which is not all about the technical Knowledge. Pull yourself to enter as
early as you can into the code chamber, eliminate others before they
eliminate you and survive longer to stand in the Chamber at last. Long survival
and maximum elimination will make you the winner.</p><br><br>
					    </p>
					    <br>
						</div>

					<div id="rules9" class="tabcontent">
						<h3></h3>
						<h2 style="text-align:center;color:#393b8e;text-align:justify;"><br>Stay till end, eliminate other or leave it</h2><br>	
							<p style="color:#000;font-size:20px;text-align:justify;">
								
									1.Each team will have exactly two participants.<br>
                                   2.Code will be allocated randomly.<br>
                                   3.It's a choice of the participant that which code they solve first.<br>
                                   4.It will be final round, there will be no prelims.<br>
                                   5.No contestant can be a member of more than one team.<br>
                                   6.No Registration is Required.<br>
                                   7.Teams involving in any malpractices will be disqualified.<br>
                                   8.Judges Decision will be final decision.
							</p> 
					</div>
			</div>
            </div>
            </div>
          </div>
		  <!--event 10-->
		  <div class="modal fade" id="ev10" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Code Riddle</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab10', this, '#777')" id="de10" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules10', this, '#777')" >Rules</button>

					<div id="ab10" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br>Look! A riddle! Time for fun!</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;">Have a knack for solving mysteries or want to code your way to victory. We have
just the right blend for you. Presenting you an event where you will be tested
based on your mystery solving as well as coding skills.</p><br><br>
					    </p>
					    <br>
					</div>

					<div id="rules10" class="tabcontent">
						<h3></h3>
						<h2 style="text-align:center;color:#393b8e;"><br>Look! A riddle! Time for fun!</h2><br>	
							<p style="color:#000;font-size:20px;text-align:justify;">
								
									1.Each team contains 2 members.<br>
                                    2.Teams completing the Phase 1 are allowed to enter the Phase 2 immediately.<br>
                                    3.Each college can have at most one team.<br>
                                    4.No contestant can be a member of more than one team.<br>
                                    5.Teams involving in any malpractices will be disqualified.
							</p> 
					</div>
			</div>
            </div>
            </div>
          </div>
	
		  <!--event 11-->
		  <div class="modal fade" id="ev11" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Zombie island</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab11', this, '#777')" id="de11" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules11', this, '#777')" >Rules</button>

					<div id="ab11" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br>Survive if you can</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;">Welcome to the Z Nation .The apocalypse is here ,so get ready with the
Shotgun for some real graphic headshots .Save yourself with whatever
Arms you have and increase the survival potential. Break the barrier of
leaderboard</p><br><br>
					    </p>
					    <br>
					   	</div>

					<div id="rules11" class="tabcontent">
						<h3></h3>
						<h2 style="text-align:center;color:#393b8e;text-align:justify;"><br>Survive if you can</h2><br>	
							<p style="color:#000;font-size:20px;text-align:justify;">
								
									 1.A single player game<br>
                                     2.Leaderboard results will be final.<br>
                                     3.Any malpractice will lead to disqualify. 
							</p> 
					</div>
			</div>
            </div>
            </div>
          </div>
		  <!--event 12-->
		  <div class="modal fade" id="ev12" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Kodecrypt</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab12', this, '#777')" id="de12" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules12', this, '#777')" >Rules</button>

					<div id="ab12" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br> Quest for best</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;">This is an online coding event where all of the participants will get a chance to
show their analytical, technical skill to each and every participant taking part in
this
event. Code it as much fast as you can, because time is not going to stop for it.
</p> <br><br>
					    </p>
					    <br>
					    </div>

					<div id="rules12" class="tabcontent">
						<h3></h3>
						<h2 style="text-align:center;color:#393b8e;"><br> Quest for best</h2><br>	
							<p style="color:#000;font-size:20px;text-align:justify;">
								
								  1. Only MCA students are eligible for prizes.<br>
                                  2. Participants college ID card will be required for verification.<br>
                                  3. Please enter valid gmail ID. We will be able to contact you only using them.<br>
                                  4. In case of any unfair activity, your account will be blocked.<br>
                                  5. In case of any malpractice, the participant can be disqualified for participation<br>
                                     and the decision of the Organizing Committee, Version19 will be final and abiding.
							</p> 
					</div>
			</div>
            </div>
            </div>
          </div>
		  <!--event 13-->
		  <div class="modal fade" id="ev13" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Smash And Leap</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab13', this, '#777')" id="de13" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules13', this, '#777')" >Rules</button>

					<div id="ab13" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br> Race of cognitive excellence</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;">Heard it ,seen it ,now it’s time to get ready for solving mysteries.
So buckle up for one of the most anticipated event of version'19 Smash And Leap
. Epiphany is upon you . Solve it ,and it will lead you on the road to finding us . We
look forward to meeting the few that will make it all the way through.</p>    <br><br>
					    </p>
					    <br>
					 </div>

					<div id="rules13" class="tabcontent">
						<h3></h3>
						<h2 style="text-align:center;"><br>Race of cognitive excellence</h2><br>	
							<p style="color:#000;font-size:20px;text-align:justify;">
								1.Use college email and password for login.<br>
2.Save your hits ,you have only 4000 hits. You will warned once when you cross danger zone.<br>
3.Two hints will be given.<br>
4.A particular question’s marks will be decreased for wrong answer.<br>
5.If someone submit answer before you then question’s marks will be decreased.	</p> 
					</div>
			</div>
            </div>
            </div>
          </div>
		  <!--event 14-->
		  <div class="modal fade" id="ev14" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Scribble</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab14', this, '#777')" id="de14" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules14', this, '#777')" >Rules</button>

					<div id="ab14" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br> Mint of Creativity</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;">Imagination has a great deal to do with winning, so imagine and innovate
something different. Get ready to tinker with cutting edges ideas and power of
creativity. Creativity involves breaking out of established patterns to look at things
in a different way. It is the event to show your creativity through doodling
masterpiece that comes from a conflict of ideas</p> <br><br>
					    </p>
					    <br>
						</div>

					<div id="rules14" class="tabcontent">
						<h3></h3>
						<h2 style="text-align:center;color:#393b8e;"><br> Mint of Creativity</h2><br>	
							<p style="color:#000;font-size:20px;text-align:justify;">
								
									1.Only one doodle per participant is allowed.<br>
                                    2.Participant must make a doodle on the word '________' and the theme will be
                                     '________'.<br>
                                    3.Doodle can be either handmade or using photoshop but the one who will use
                                      photoshop will be given priority.<br>
                                    4.You can add short description of your creativity.<br>
                                    5.Submissions are starting from '_______'.<br>
                                    6.Judgement criteria will be according to artistic skills, creativity and the theme
                                      representation.<br>
                                    7.Submit your entries at '_______' with participant name, college name and
                                      contact number.<br>
                                    8.Each doodle will be posted on official facebook page of Version, NIT Trichy.
                                      Maximum Facebook likes, and jury decision will be final.
							</p> 
					</div>
			</div>
            </div>
            </div>
          </div>
		  <!--event 15-->
		  <div class="modal fade" id="ev15" role="dialog">
            <div class="modal-dialog">
    
            <!-- Modal content-->
            <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h2 class="modal-title" style="color:#000;font-family:cursive;">Pixelate</h2>
            </div>
        
		    <div class="inner_div">
		    <button class="tablink" onclick="openPage('ab15', this, '#777')" id="de15" style="border-right:2px solid white;">About</button>
		    <button class="tablink" onclick="openPage('rules15', this, '#777')" >Rules</button>

					<div id="ab15" class="tabcontent" style="display:block;">
						<h2 style="text-align:center;color:#393b8e;"><br>MAKE IT RAW</h2><br>
						<p style="color:#000;font-size:20px;text-align:justify;">Pixelate is a photography event to showcase your talent.For some people it is hobby
and for some it is their passion.This event gives you an opportunity to seperate yourself
from the mundane and show your artistry.</p>
					    <br><br>
					    </p>
					    <br>
					    	</div>

					<div id="rules15" class="tabcontent">
						<h3></h3>
						<h2 style="text-align:center;color:#393b8e;"><br>MAKE IT RAW</h2><br>
							<p style="color:#000;font-size:20px;text-align:justify;">
									
									1.Participants will be provided with two

Themes(__________________). Best photo will be declared as winner.<br>
 

2.	Photos must be on manual mode and clicked on manual focus mode.<br>

3.	Exposure triangle criteria must be followed.<br>

4.	Only .raw and .jpg formats are allowed.<br>

5.	Basic editing can be done using lightroom. Photoshop not allowed.<br>

6.	You need to send both edited and unedited photos.<br>

	<br><u>How to submit:</u><br><br>

1.  Send one-one best photo on each theme(original + edited + raw) followed by above rules with the note containing.<br>

2.	Name of college.<br>

3.	Caption.<br>

4.	Email id(the one which you used to register for version).<br>

5.	Contact number.<br>

6.	Tools used in lightroom.<br>

7.	Photos will be posted on version, nit trichy facebook page.<br><br>

Judgment will be based on likes and the decision of jury.
 


							</p> 
					</div>
			</div>
            </div>
            </div>
          </div>
		  
              <!-- Background small bubble -->
	        <div id="particles-js" style="position:fixed;"></div> 
 
            <script src="http://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
                <div style="position:absolute;z-index:1000;height:100%;width:100%;text-align:center;">
                 
				 
				 
				 <!--event details-->
			 
                 <div class="event_container animated zoomIn" id="events_name">
  <div class="heading">Events</div>
  <div class="item-container" >
    <a href="javascript:void(0)" onclick="onstage()">
      <div class="item" style="background-image:url('img/onstage.jpg');background-position:center;background-size:cover;">
               
                                        <div class="item-hover" style="background-color:;"></div>
                                           <img src="img/onstage.png" style="height:117px;width:223px;"/>
       
      </div>
    </a>
    <a href="javascript:void(0)" onclick="online()">
      <div class="item" style="background-image:url('img/online.jpg');background-position:center;background-size:cover;">
                                           <div class="item-hover" style="background-color:;"></div>
                                           <img src="img/online.png" style="height:117px;width:223px;"/>
                                           
      </div>
      
    </a>
    <a href="javascript:void(0)" onclick="offstage()">
      <div class="item" style="background-image:url('img/offstage.jpg');background-position:center;background-size:cover;">
                                           <div class="item-hover" style="background-color:;"></div>
                                           <img src="img/offstage.png" style="height:117px;width:223px;"/>

      </div>
    </a>
	 <a href="javascript:void(0)" onclick="submit()">
      <div class="item" style="background-image:url('img/submis.jpg');background-position:center;background-size:cover;">
        <div class="item-hover" style="background-color:;"></div>
        <img src="img/offstage.png" style="height:117px;width:223px;"/>

      </div>
    </a>
  </div>
</div>  


                         <!--onstage events-->

                        <div class="event_container animated zoomIn" id="onstage" style="display:none;">	
                            <div class="heading">
                                 <span style="float:left;"><a href="javascript:void(0)" onclick="closedv()"><i class="fa fa-arrow-circle-left" style="font-size:48px;color:#fff;"></i></a></span>
                                 <span>Onstage Events</span>
                            </div>
                            <div class="item-container bapu" style="">
                                <a href="javascript:void(0)" onclick="opendiv('ev1','de1')" data-toggle="modal" data-target="#ev1">
                                    <div class="item" style="background-image:url('img/onstage.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
                                           <img src="logo/phoenix.png" style="height:160px;width:238px;"/>
                                           
                                        </div>
										
                                    </div>
                                </a>
    <a href="javascript:void(0)" onclick="opendiv('ev2','de2')" data-toggle="modal" data-target="#ev2">
                                    <div class="item" style="background-image:url('img/onstage.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
										   
                                           <img src="logo/mindmatrix.png" style="height:159px;width:223px;"/>
                                           
                                        </div>
										
                                    </div>
                                </a>
                 <a href="javascript:void(0)" onclick="opendiv('ev3','de3')" data-toggle="modal" data-target="#ev3">
                                    <div class="item" style="background-image:url('img/onstage.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
                                           <img src="logo/technothon.png" style="height:158px;width:223px;"/>
                                           
                                        </div>
										
                                    </div>
                                </a>
	 
	
  </div>
</div> 

       <!--online events-->
<div class="event_container animated zoomIn" id="online" style="display:none;">
							
 <div class="heading">
 <span style="float:left;"><a href="javascript:void(0)" onclick="closedv()"><i class="fa fa-arrow-circle-left" style="font-size:48px;color:#fff;"></i></a></span>
 <span>Online Events</span>
 </div>
 <div >
  <div class="item-container bapu">
    <a href="javascript:void(0)" onclick="opendiv('ev11','de11')" data-toggle="modal" data-target="#ev11">
                                    <div class="item" style="background-image:url('img/online.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
                                           <img src="logo/zombieisland.png" style="height:162px;width:223px;"/>
                                           
                                        </div>
										
                                    </div>
                                </a>
    <a href="javascript:void(0)" onclick="opendiv('ev12','de12')" data-toggle="modal" data-target="#ev12">
                                    <div class="item" style="background-image:url('img/online.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
                                           <img src="logo/kodecrypt.png" style="height:165px;width:280px;"/>
                                           
                                        </div>
										
                                    </div>
                                </a>
    <a href="javascript:void(0)" onclick="opendiv('ev13','de13')" data-toggle="modal" data-target="#ev13">
                                    <div class="item" style="background-image:url('img/online.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
                                           <img src="logo/smashandleap.png" style="height:158px;width:223px;"/>
                                           
                                        </div>
										
                                    </div>
                                </a>
	 
  </div>
</div> 
</div>
<!--offstage events-->

    <div class="event_container animated zoomIn" id="offstage" style="display:none;">
							
 <div class="heading">
 <span style="float:left;"><a href="javascript:void(0)" onclick="closedv()"><i class="fa fa-arrow-circle-left" style="font-size:48px;color:#fff;"></i></a></span>
 <span>Offstage Events</span>
 </div>
  <div class="item-container">
    <a href="javascript:void(0)" onclick="opendiv('ev5','de5')" data-toggle="modal" data-target="#ev5">
                                    <div class="item" style="background-image:url('img/offstage.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
                                           <img src="logo/enquizitica.png" style="height:158px;width:263px;"/>
                                           
                                        </div>
										
                                    </div>
                                </a>
    <a href="javascript:void(0)" onclick="opendiv('ev6','de6')" data-toggle="modal" data-target="#ev6">
                                    <div class="item" style="background-image:url('img/offstage.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
                                           <img src="logo/mindshuffler.png" style="height:159px;width:270px;"/>
                                           
                                        </div>
										
                                    </div>
                                </a>
    <a href="javascript:void(0)" onclick="opendiv('ev7','de7')" data-toggle="modal" data-target="#ev7">
                                    <div class="item" style="background-image:url('img/offstage.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
                                           <img src="logo/mystrymaze.png" style="height:158px;width:223px;"/>
                                           
                                        </div>
										
                                    </div>
                                </a>
	 <a href="javascript:void(0)" onclick="opendiv('ev8','de8')" data-toggle="modal" data-target="#ev8">
                                    <div class="item" style="background-image:url('img/offstage.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
                                           <img src="logo/eventx.png" style="height:162px;width:243px;"/>
                                           
                                        </div>
										
                                    </div>
                                </a>
	 <a href="javascript:void(0)" onclick="opendiv('ev9','de9')" data-toggle="modal" data-target="#ev9">
                                    <div class="item" style="background-image:url('img/offstage.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
                                           <img src="logo/codechamber.png" style="height:158px;width:223px;"/>
                                           
                                        </div>
										
                                    </div>
                                </a>
    <a href="javascript:void(0)" onclick="opendiv('ev10','de10')" data-toggle="modal" data-target="#ev10">
                                    <div class="item" style="background-image:url('img/offstage.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
                                           <img src="logo/coderiddle.png" style="height:158px;width:237px;"/>
                                           
                                        </div>
										
                                    </div>
                                </a>
    
	 <a href="javascript:void(0)" onclick="opendiv('ev4','de4')" data-toggle="modal" data-target="#ev4">
                                    <div class="item" style="background-image:url('img/offstage.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
                                           <img src="logo/gamerseden.png" style="height:162px;width:258px;"/>
                                           
                                        </div>
										
                                    </div>
                                </a>
	 
  </div>
</div> 
<!--submission Events-->
<div class="event_container animated zoomIn" id="submit" style="display:none;">
							
 <div class="heading">
 <span style="float:left;"><a href="javascript:void(0)" onclick="closedv()"><i class="fa fa-arrow-circle-left" style="font-size:48px;color:#fff;"></i></a></span>
 <span>Submission Events</span>
 </div>
  <div class="item-container bapu1" style="">
    <a href="javascript:void(0)" onclick="opendiv('ev15','de15')" data-toggle="modal" data-target="#ev15">
                                    <div class="item" style="background-image:url('img/submis.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
                                           <img src="logo/pixlete.png" style="height:158px;width:230px;"/>
                                           
                                        </div>
										 
                                    </div>
                                </a>
    
	 <a href="javascript:void(0)" onclick="opendiv('ev14','de14')" data-toggle="modal" data-target="#ev14">
                                    <div class="item" style="background-image:url('img/submis.jpg');background-position:center;background-size: cover;">
                                        <span class="emoji">&nbsp;</span>
                                        <div class="item-hover" style="opacity:1;background-color:#fff;">
                                           <img src="logo/scribble.png" style="height:158px;width:251px;"/>
                                           
                                        </div>
										
                                    </div>
                                </a>
	 
  </div>
</div> 
  


        
                   <!-- menu Icon-->
				   <div class="site-nav-animation-wrapper menu-animation-wrapper">
      <div class="site-nav-animated-background menu-animated-background"></div>
    </div>
    <a href="" class="menu menu-white menu-spinkit">
      <span class="menu-icon-line-1 menu-icon-line"></span>
      <span class="menu-icon-line-2 menu-icon-line"></span>
      <span class="menu-icon-line-3 menu-icon-line"></span>
    </a>
       
   <div class="site-nav-overlay js-nav">
      <div class="nav-content">
        <div class="js-nav-header nav-header">
          <span class="nav-header-text">Version'19</span>
          <div class="nav-header-line js-nav-header-line"></div>
        </div>

        <ul class="nav-categories">
          <li class="nav-category js-nav-animate"><a href="index.php" class="nav-link">Home</a></li>
          <li class="nav-category js-nav-animate"><a href="#" class="nav-link">Event</a></li>
          <li class="nav-category js-nav-animate"><a href="team.php" class="nav-link">Teams</a></li>
          <li class="nav-category js-nav-animate"><a href="contact.php" class="nav-link">Contact</a></li>
		  <li class="nav-category js-nav-animate"><a href="about.php" class="nav-link">About</a></li>
		  <li class="nav-category js-nav-animate"><a href="gallery.php" class="nav-link">Gallery</a></li>
		  <li class="nav-category js-nav-animate"><a href="register.php" class="nav-link">Registration</a></li>
        </ul>

        <div class="nav-sublinks js-nav-animate">
          <div class="js-nav-animate">
         <a class="nav-link nav-sublink" target="_blank" href="https://www.facebook.com/versionmeet/"><i class="fab fa-facebook-f"></i></a>
          <a class="nav-link nav-sublink" target="_blank" href="https://www.youtube.com/channel/UCtD7JZ4zH72M8lSzo1y89gQ"><i class="fab fa-youtube"></i></a>
          <a class="nav-link nav-sublink" target="_blank" href="https://www.instagram.com/version_nit_trichy/"><i class="fab fa-instagram"></i></a>
          </div>
        </div>
      </div>

    </div>
			<div style="margin-top:22%;bottom:1%;color:#fff;width:100%;text-align:center;font-size:15px;">
	Made With ❤️ By EEC.
	</div>
                </div>
              <!-- end of section-->
			  
			  <!--script section-->
	    
			<script>
	 function onstage() {
  document.getElementById("onstage").style.display = "block";
   document.getElementById("events_name").style.display = "none";
  
}
	 function online() {
  document.getElementById("online").style.display = "block";
   document.getElementById("events_name").style.display = "none";
  
}
	 function offstage() {
  document.getElementById("offstage").style.display = "block";
   document.getElementById("events_name").style.display = "none";
  
}
	 function submit() {
  document.getElementById("submit").style.display = "block";
   document.getElementById("events_name").style.display = "none";
  
}

	 function closedv() {
	 	document.getElementById("onstage").style.display = "none";
  document.getElementById("events_name").style.display = "block";
  document.getElementById("online").style.display = "none";
  document.getElementById("offstage").style.display = "none";
  document.getElementById("submit").style.display = "none";
   
  
}
</script>
 <script>

function openPage(pageName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(pageName).style.display = "block";
  elmnt.style.backgroundColor = color;

}


// Get the element with id="defaultOpen" and click on it

  function opendiv(a,b) {
  document.getElementById(a).style.display = "block";

 document.getElementById(b).click();
  
}
  function closediv(a) {
  document.getElementById(a).style.display = "none";
}
</script>
<script src="https://cdn.jsdelivr.net/gh/cferdinandi/smooth-scroll@15.0.0/dist/smooth-scroll.polyfills.min.js"></script>

	    <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>
	     <script  src="js/bubble_script.js"></script>
<script src="js/nav.js"></script>

    </body>
</html>